"""Stillwater V6: meter-scale upholstery tailored onto the approved V5 furniture.

Call apply_upholstery() after loading the V5 .blend; modifies only the in-memory
copy. Cushions retain their objects and transforms, and the original local
outer limits bound all new geometry. No textures, caches, or plugins required.
"""
import bpy
import hashlib
import math
import re
from collections import Counter
from mathutils import Vector

SOFAS={
    'Living | wool sectional':'oat wool',
    'West salon | south sofa':'flax',
    'West salon | media sofa':'flax',
    'Primary | olive day lounge':'olive',
    'Family landing | two-seat reading settee':'olive',
    'Roof lounge | sheltered linen sectional':'outdoor flax',
    'Primary terrace | low outdoor lounge':'outdoor flax',
}
CHAIRS={
    'Living oak chair':'oat wool',
    'Dining | ash chair':'flax',
    'Dining | end chair':'flax',
    'Study | upholstered desk chair':'olive',
    'Roof lounge | pool-facing oak seat':'outdoor flax',
    'Bedroom balcony | oak chair':'outdoor flax',
    'Atelier | facing the mountain':'flax',
}
PALETTE={
    'oat wool':((.42,.375,.313),(.68,.622,.525),.84,.26,275),
    'flax':((.43,.388,.312),(.64,.588,.474),.83,.21,310),
    'olive':((.164,.184,.128),(.298,.320,.224),.88,.25,295),
    'outdoor flax':((.388,.370,.306),(.612,.575,.482),.79,.15,345),
    'accent tobacco':((.235,.145,.093),(.376,.254,.175),.87,.27,302),
}
SOFA_ROLES={
    'slim upholstered deck':'deck',
    'feather seat cushion':'cushion',
    'loose back cushion':'sofa_back',
    'rounded upholstered arm':'arm',
    'contrast accent pillow':'pillow',
}
CHAIR_ROLES={'seat':'chair_seat','curved upholstered back':'chair_back'}
ROLE_CFG={
    # Plan corner radius, seam-loop index, normal axis, fine fold amplitude (metres).
    'deck':(.065,5,'z',.0012),
    'cushion':(.083,6,'z',.0052),
    'sofa_back':(.072,6,'-y',.0040),
    'arm':(.061,5,'z',.0030),
    'pillow':(.059,5,'-y',.0042),
    'chair_seat':(.048,5,'z',.0022),
    'chair_back':(.037,5,'-y',.0014),
    'exterior_seat':(.071,6,'z',.0027),
    'exterior_back':(.049,6,'-y',.0026),
}

def _materials(family):
    low,high,rough,sheen,thread=PALETTE[family]
    label='V6 | Upholstery | '+family
    textile=bpy.data.materials.get(label)
    if textile is None:
        textile=bpy.data.materials.new(label); textile.use_nodes=True
        n=textile.node_tree.nodes; l=textile.node_tree.links
        bs=n.get('Principled BSDF')
        textile.diffuse_color=tuple(.55*a+.45*b for a,b in zip(low,high))+(1.,)
        bs.inputs['Roughness'].default_value=rough
        bs.inputs['Sheen Weight'].default_value=sheen
        bs.inputs['Sheen Roughness'].default_value=.64
        tc=n.new('ShaderNodeTexCoord');tc.location=(-900,80)
        # UV charts are authored in physical meters. Slight multi-strand twist
        # irregularity avoids a razor-crisp textile grid at oblique angles.
        noise=n.new('ShaderNodeTexNoise');noise.label='Dye variation across cloth'
        noise.location=(-690,280);noise.inputs['Scale'].default_value=39
        noise.inputs['Detail'].default_value=2.4
        l.new(tc.outputs['Object'],noise.inputs['Vector'])
        color=n.new('ShaderNodeValToRGB');color.location=(-435,285)
        color.color_ramp.elements[0].position=.12;color.color_ramp.elements[0].color=(*low,1)
        color.color_ramp.elements[1].position=.89;color.color_ramp.elements[1].color=(*high,1)
        l.new(noise.outputs['Fac'],color.inputs['Fac'])
        wave=[]
        for direction,x,y,rate in [('X',-650,5,1.),('Y',-650,-190,.89)]:
            a=n.new('ShaderNodeTexWave');a.location=(x,y);a.wave_type='BANDS'
            a.bands_direction=direction;a.wave_profile='SIN';a.inputs['Scale'].default_value=thread*rate
            a.inputs['Distortion'].default_value=.65;a.inputs['Detail Scale'].default_value=1.4
            l.new(tc.outputs['UV'],a.inputs['Vector']);wave.append(a)
        cross=n.new('ShaderNodeMath');cross.operation='MULTIPLY';cross.location=(-395,-70)
        for i,a in enumerate(wave):l.new(a.outputs['Fac'],cross.inputs[i])
        fiber=n.new('ShaderNodeTexNoise');fiber.location=(-675,-432)
        fiber.inputs['Scale'].default_value=1050;fiber.inputs['Detail'].default_value=2.
        l.new(tc.outputs['Object'],fiber.inputs['Vector'])
        blend=n.new('ShaderNodeMixRGB');blend.blend_type='MIX';blend.location=(-165,-53)
        blend.inputs[0].default_value=.34
        l.new(cross.outputs[0],blend.inputs[1]);l.new(fiber.outputs['Fac'],blend.inputs[2])
        shades=n.new('ShaderNodeValToRGB');shades.location=(-180,167)
        shades.color_ramp.elements[0].color=(.68,.68,.68,1)
        shades.color_ramp.elements[1].color=(1.,1.,1.,1)
        l.new(blend.outputs[0],shades.inputs['Fac'])
        tint=n.new('ShaderNodeMixRGB');tint.blend_type='MULTIPLY';tint.inputs[0].default_value=.47;tint.location=(65,200)
        l.new(color.outputs['Color'],tint.inputs[1]);l.new(shades.outputs['Color'],tint.inputs[2]);l.new(tint.outputs[0],bs.inputs['Base Color'])
        bump=n.new('ShaderNodeBump');bump.location=(75,-70);bump.inputs['Strength'].default_value=.27
        bump.inputs['Distance'].default_value=.0012 if family=='oat wool' else .00085
        l.new(blend.outputs[0],bump.inputs['Height']);l.new(bump.outputs['Normal'],bs.inputs['Normal'])
        bs.location=(290,185);n.get('Material Output').location=(615,190)
    line=bpy.data.materials.get(label+' welt')
    if line is None:
        line=bpy.data.materials.new(label+' welt');line.use_nodes=True
        c=tuple(.87*(.57*a+.43*b) for a,b in zip(low,high))+(1.,)
        line.diffuse_color=c;bs=line.node_tree.nodes.get('Principled BSDF')
        bs.inputs['Base Color'].default_value=c;bs.inputs['Roughness'].default_value=.83
        bs.inputs['Sheen Weight'].default_value=sheen
    thread_m=bpy.data.materials.get(label+' topstitch')
    if thread_m is None:
        thread_m=bpy.data.materials.new(label+' topstitch');thread_m.diffuse_color=tuple(.33*a+.67*b for a,b in zip(low,high))+(1.,)
        thread_m.use_nodes=True;bs=thread_m.node_tree.nodes.get('Principled BSDF')
        bs.inputs['Base Color'].default_value=thread_m.diffuse_color;bs.inputs['Roughness'].default_value=.87
        bs.inputs['Sheen Weight'].default_value=.20
    return textile,line,thread_m


def _perimeter(w,d,r):
    """Counter-clockwise rounded rectangle with resolved long straight edges."""
    a,b=w*.5,d*.5
    r=min(r,a*.82,b*.82)
    centers=((a-r,b-r),(-a+r,b-r),(-a+r,-b+r),(a-r,-b+r))
    points=[]
    for i,(cx,cy) in enumerate(centers):
        p=[]
        for k in range(9):
            t=(i+k/8)*math.pi*.5
            p.append((cx+r*math.cos(t),cy+r*math.sin(t)))
        if points:
            old=points[-1];dest=p[0]
            count=max(1,math.ceil(math.dist(old,dest)/.033))
            points.extend((old[0]+(dest[0]-old[0])*j/count,old[1]+(dest[1]-old[1])*j/count) for j in range(1,count))
        points.extend(p)
    old,dest=points[-1],points[0];count=max(1,math.ceil(math.dist(old,dest)/.033))
    points.extend((old[0]+(dest[0]-old[0])*j/count,old[1]+(dest[1]-old[1])*j/count) for j in range(1,count))
    return points


def _round_path(pts,r,radial=7,closed=True):
    """Mesh a cloth cord or a short sewn run. Uses tangent frames."""
    vv=[];ff=[];length=len(pts)
    P=list(map(Vector,pts))
    for i,p in enumerate(P):
        prev=P[(i-1)%length] if closed or i else p
        nxt=P[(i+1)%length] if closed or i<length-1 else p
        tangent=(nxt-prev).normalized()
        ref=Vector((0,0,1)) if abs(tangent.z)<.83 else Vector((0,1,0))
        norm=tangent.cross(ref).normalized();binorm=tangent.cross(norm).normalized()
        for k in range(radial):
            theta=math.tau*k/radial
            vv.append(tuple(p+r*(norm*math.cos(theta)+binorm*math.sin(theta))))
    for i in range(length if closed else length-1):
        for k in range(radial):
            ni=(i+1)%length;nk=(k+1)%radial
            ff.append((i*radial+k,i*radial+nk,ni*radial+nk,ni*radial+k))
    if not closed:
        ff.append(tuple(reversed(range(radial))))
        ff.append(tuple(range((length-1)*radial,length*radial)))
    return vv,ff


def _mesh(name,vs,fs,mat):
    me=bpy.data.meshes.new(name)
    me.from_pydata(vs,[],fs);me.materials.append(mat);me.update()
    for p in me.polygons:p.use_smooth=True
    return me


def _add_detail(original,kind,vs,fs,mat):
    prefix='V6 | '+kind+' | '+original.name
    # Blender limits datablock names: keep a stable unique suffix on repeats.
    code=hashlib.sha1(prefix.encode()).hexdigest()[:6]
    name=prefix[:56]+' '+code
    detail=bpy.data.objects.new(name,_mesh(name,vs,fs,mat))
    original.users_collection[0].objects.link(detail)
    detail.matrix_world=original.matrix_world.copy()
    detail['upholstery_detail']=kind
    detail['source_furniture']=original.name
    return detail


def _apply_piece(o,role,family):
    radius,welt_index,axis,amp=ROLE_CFG[role]
    bb=[Vector(p) for p in o.bound_box];lo=[min(v[i] for v in bb) for i in range(3)];hi=[max(v[i] for v in bb) for i in range(3)]
    spans=tuple(b-a for a,b in zip(lo,hi));cx,cy,cz=[.5*(a+b) for a,b in zip(lo,hi)]
    assert min(spans)>.035, (o.name,spans)
    if axis=='-y':
        w,d,h=spans[0],spans[2],spans[1]
        def convert(x,y,z):return (cx+x,cy-z,cz+y)
    else:
        w,d,h=spans
        def convert(x,y,z):return (cx+x,cy+y,cz+z)
    wool,welt,sewing=_materials(family)
    phase=int(hashlib.sha1(o.name.encode()).hexdigest()[:8],16)/2**32*math.tau
    edge=_perimeter(w,d,radius)
    # Closed foam shell with broad, almost flat faces, fuller bolsters, and
    # small relaxed compression folds near the sewn boundary rather than noisy displacement.
    shape=[(.14,-.485),(.43,-.473),(.69,-.443),(.875,-.373),(.962,-.243),(.993,-.079),
           (.984,.128),(.947,.280),(.862,.388),(.695,.441),(.475,.465),(.226,.471),(.10,.469)]
    N=len(edge);vs=[];fs=[];uv=[]
    U=[0.]
    for i in range(N):U.append(U[-1]+math.dist(edge[i],edge[(i+1)%N]))
    def vert(i,s,n):
        ex,ey=edge[i];x=ex*s;y=ey*s
        uvx=x/(w*.5);uvy=y/(d*.5)
        along=math.atan2(ey/d,ex/w)
        # A relaxed depression gets deeper toward one sitting side; infrequent
        # diagonal creases die out well before the opposite face.
        press=max(0,1-(uvx+.17*math.sin(phase))**2*2.8-(uvy+.25)**2*2.5)
        wav=(.57*math.sin(4*along+phase+3*s)+.28*math.sin(9*along-phase)+.15*math.cos(16*along+phase))
        side_xy=amp*.45*math.exp(-((s-.91)/.17)**2)*wav
        x+=side_xy*math.cos(along);y+=side_xy*math.sin(along)
        z=h*n + amp*(.40*wav)*math.exp(-((s-.80)/.19)**2)
        if n>.27:z-=amp*press*(.65 if role in ('chair_back','arm','deck') else 1.4)
        # The chair back sweeps toward the sitter at its wings, in existing thickness.
        if role=='chair_back':z-=.007*(1-uvx*uvx)*math.exp(-((s-.40)/.60)**2)
        # asymmetric bias in throw pillows only; stays inside the existing volume.
        if role=='pillow':z+=.003*uvy*math.sin(phase)
        return (max(-w*.5+.0014,min(w*.5-.0014,x)),
                max(-d*.5+.0014,min(d*.5-.0014,y)),
                max(-h*.5+.0008,min(h*.5-.0008,z)))
    layers=[]
    for s,n in shape:
        layer=[vert(i,s,n) for i in range(N)]
        layers.append(layer);vs.extend(convert(*p) for p in layer)
    vs.extend((convert(0,0,-h*.49),convert(0,0,h*.469-amp)))
    V=[0.]
    for k in range(1,len(shape)):
        V.append(V[-1]+sum(math.dist(x,y) for x,y in zip(layers[k],layers[k-1]))/N)
    for j in range(len(shape)-1):
        for i in range(N):
            k=(i+1)%N
            fs.append((j*N+i,j*N+k,(j+1)*N+k,(j+1)*N+i))
            if j<=2 or j>=8:
                # The broad panels are cut on the cloth grain, not radially.
                uv.append([layers[a][b][:2] for a,b in ((j,i),(j,k),(j+1,k),(j+1,i))])
            else:
                uv.append(((U[i],V[j]),(U[i+1],V[j]),(U[i+1],V[j+1]),(U[i],V[j+1])))
    for j,sign,ci in ((0,-1,len(vs)-2),(len(shape)-1,1,len(vs)-1)):
        for i in range(N):
            k=(i+1)%N
            x,y=(i,k) if sign>0 else (k,i)
            fs.append((j*N+x,j*N+y,ci))
            uv.append((layers[j][x][:2],layers[j][y][:2],(0.,0.)))
    old=o.data
    me=_mesh(o.name+' | sewn shell',vs,fs,wool)
    chart=me.uv_layers.new(name='Cut fabric / meters')
    assert sum(len(f) for f in uv)==len(me.loops)
    chart.data.foreach_set('uv',[a for face in uv for pair in face for a in pair])
    for mo in list(o.modifiers):o.modifiers.remove(mo)
    o.data=me
    if old.users==0:bpy.data.meshes.remove(old)
    o['upholstery_v6_role']=role
    o['upholstery_v6_textile']=family
    bounds=[lo,hi];outputs=[o]
    if role not in ('deck','arm'):
        # A traversable modular scene must keep the cord within the original bounds.
        cord_d=.0019 if role in ('cushion','pillow','sofa_back') else .0013
        coords=layers[welt_index]
        pts=[]
        for x,y,z in coords:
            xx=max(-w*.5+cord_d,min(w*.5-cord_d,x))
            yy=max(-d*.5+cord_d,min(d*.5-cord_d,y))
            pts.append((xx,yy,z))
        cv,cf=_round_path(pts,cord_d)
        outputs.append(_add_detail(o,'self welt',[convert(*p) for p in cv],cf,welt))
        # Tailoring thread on both main living cushion faces only. One combined
        # mesh per cushion keeps this fine physical detail cheap to edit or hide.
        if o.name.startswith('Living | wool sectional') and role in ('cushion','pillow','sofa_back'):
            cross_section=layers[welt_index+1]
            all_v=[];all_f=[]
            for i in range(N):
                a,b=map(Vector,(cross_section[i],cross_section[(i+1)%N]))
                if a.y>0 or b.y>0:continue
                length=(b-a).length
                if not length:continue
                pitch=.0066
                for j in range(max(1, int(length/pitch))):
                    f=(j+.48)/max(1,int(length/pitch))
                    aa=a.lerp(b,max(0,f-.00122/length));bb=a.lerp(b,min(1,f+.00122/length))
                    # Barely raised stitch ends, set immediately inside the rounded bounding edge.
                    for p in (aa,bb):
                        p.x=max(-w*.5+.0008,min(w*.5-.0008,p.x*1.0017))
                        p.y=max(-d*.5+.0008,min(d*.5-.0008,p.y*1.0017))
                        p.z+=.00046
                    sv,sf=_round_path([aa,bb],.00034,5,False)
                    off=len(all_v);all_v.extend(convert(*q) for q in sv);all_f.extend(tuple(x+off for x in f) for f in sf)
            if all_f:outputs.append(_add_detail(o,'saddle stitch',all_v,all_f,sewing))
    # Check every replacement/seam vertex in source object space, independent of orientation.
    max_over=max(max(max(lo[i]-v.co[i],v.co[i]-hi[i]) for i in range(3)) for obj in outputs for v in obj.data.vertices)
    if max_over>2e-6:raise ValueError((o.name,'silhouette envelope overrun',max_over))
    return len(outputs)-1,len(me.polygons),bounds


def _role(tag,roles):
    if tag in roles:return roles[tag]
    # Blender's 63-character object limit cuts successive duplicate V5 names
    # even further than the first instance; full family prefix is still present.
    match=[v for k,v in roles.items() if len(tag)>=14 and k.startswith(tag)]
    return match[0] if len(match)==1 else None


def apply_upholstery():
    if bpy.context.scene.get('V6 upholstery verified'):
        raise RuntimeError('Upholstery already applied to this scene')
    counts=Counter(); source=[]
    for o in list(bpy.context.scene.objects):
        if o.type!='MESH' or o.hide_render:continue
        name=re.sub(r'\.\d{3}$','',o.name)
        prefix,_,tag=name.rpartition(' | ');tag=tag.rstrip()
        sofa_role=_role(tag,SOFA_ROLES) if prefix in SOFAS else None
        chair_role=_role(tag,CHAIR_ROLES) if prefix in CHAIRS else None
        if sofa_role:
            fam=SOFAS[prefix];role=sofa_role
            if role=='pillow':
                if fam=='oat wool':
                    fam='olive' if o.name[-4:-3]!='.' else 'accent tobacco'
                else:
                    m=o.data.materials[0];fam='olive' if 'Sage' in m.name else fam
        elif chair_role:
            fam,role=CHAIRS[prefix],chair_role
        elif prefix=='Garden lounge' and tag in ('warm linen cushion','woven linen back pillow'):
            fam='outdoor flax';role='exterior_seat' if tag=='warm linen cushion' else 'exterior_back'
        else:continue
        added,faces,bounds=_apply_piece(o,role,fam)
        counts[role]+=1;counts['detail meshes']+=added;counts['shell polygons']+=faces
        source.append(o.name)
    if any(counts[k]!=n for k,n in {'deck':7,'cushion':21,'sofa_back':21,'arm':14,'pillow':14,'chair_seat':15,'chair_back':15,'exterior_seat':2,'exterior_back':2}.items()):
        raise RuntimeError(f'V5 furniture inventory not found: {dict(counts)}')
    build={'counts':dict(counts),'upgraded_meshes':sorted(source),'local_envelope_growth_m':0.}
    bpy.context.scene['V6 upholstery verified']=True
    bpy.context.view_layer.update()
    return build


if __name__=='__main__':
    import json
    print('V6_UPHOLSTERY',json.dumps(apply_upholstery()),flush=True)

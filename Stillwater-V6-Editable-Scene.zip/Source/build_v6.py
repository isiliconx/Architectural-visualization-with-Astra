"""Build a separate editable Stillwater V6 copy from the hash-verified V5 master."""
import argparse
import hashlib
import json
import math
from math import pi,sin,cos
from pathlib import Path
import sys

import bpy
from mathutils import Vector

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from architecture_v6 import apply_architecture
from landscape_v6 import refine_landscape
from lighting_v6 import apply_lighting_and_cameras
from upholstery_v6 import apply_upholstery
from frames_v6 import apply_chair_frames
from horizon_v6 import apply_horizon


EXPECTED="7e3bae12a0061a6d9ba818500d4855a67831ba91f73bb5397cdf3fc6be70e90f"

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()

def collection(name):
    if name not in bpy.data.collections:
        c=bpy.data.collections.new(name)
        scene.collection.children.link(c)
        return c
    return bpy.data.collections[name]

def material(name,color,rough=.6,metal=0.):
    m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
    bs=m.node_tree.nodes.get("Principled BSDF")
    bs.inputs["Base Color"].default_value=(*color,1);bs.inputs["Roughness"].default_value=rough;bs.inputs["Metallic"].default_value=metal
    return m

def textured(name,c1,c2,scale=4,rough=.7,bump=.035,dist=.07):
    m=material(name,c1,rough)
    n,l=m.node_tree.nodes,m.node_tree.links;bs=n.get("Principled BSDF")
    p=n.new("ShaderNodeTexCoord")
    no=n.new("ShaderNodeTexNoise")
    no.inputs["Scale"].default_value=scale;no.inputs["Detail"].default_value=3.3;no.inputs["Roughness"].default_value=.63
    l.new(p.outputs["Object"],no.inputs["Vector"])
    ra=n.new("ShaderNodeValToRGB");ra.color_ramp.elements[0].position=.20;ra.color_ramp.elements[1].position=.83
    ra.color_ramp.elements[0].color=(*c1,1);ra.color_ramp.elements[1].color=(*c2,1)
    l.new(no.outputs["Fac"],ra.inputs[0]);l.new(ra.outputs[0],bs.inputs["Base Color"])
    tiny=n.new("ShaderNodeTexNoise");tiny.inputs["Scale"].default_value=236; tiny.inputs["Detail"].default_value=2.1
    l.new(p.outputs["Object"],tiny.inputs["Vector"])
    bu=n.new("ShaderNodeBump");bu.inputs["Strength"].default_value=bump;bu.inputs["Distance"].default_value=min(dist,.0026)
    l.new(tiny.outputs["Fac"],bu.inputs["Height"]);l.new(bu.outputs["Normal"],bs.inputs["Normal"])
    bs.inputs["Coat Weight"].default_value=.15
    bs.inputs["Coat Roughness"].default_value=.28
    return m

def mesh_obj(name,vertices,faces,mats,indices=None):
    me=bpy.data.meshes.new(name);me.from_pydata(vertices,[],faces);me.update()
    o=bpy.data.objects.new(name,me);active.objects.link(o)
    for m in mats:me.materials.append(m)
    if indices is not None:me.polygons.foreach_set("material_index",indices)
    return o

def check_support(checks,reference):
    dep=bpy.context.evaluated_depsgraph_get()
    from mathutils.bvhtree import BVHTree
    results=[]
    for row in checks:
        p=Vector(row["base_blender_m"])
        found=[]
        for o in reference:
            if not o.name.startswith(row["support_match"]):continue
            bvh=BVHTree.FromObject(o,dep)
            inv=o.matrix_world.inverted()
            ori=inv@(p+Vector((0,0,.075)))
            dire=(inv.to_3x3()@Vector((0,0,-1))).normalized()
            hit=bvh.ray_cast(ori,dire,.155)
            if hit[0] is not None:
                h=(o.matrix_world@hit[0]).z
                found.append(abs(h-p.z))
        if not found or min(found)>.0035:raise RuntimeError(f"Unsupported lived-in prop: {row}")
        results.append(min(found))
    return {"anchors":len(results),"maxErrorM":max(results)}

def main():
    global scene,active,woodlight,linen,sage
    v=sys.argv[sys.argv.index("--")+1:]
    pa=argparse.ArgumentParser()
    pa.add_argument("--out",type=Path,required=True)
    a=pa.parse_args(v)
    original=Path(bpy.data.filepath).resolve()
    out=a.out.resolve()
    assert original!=out and out.suffix==".blend" and not out.exists()
    assert sha(original)==EXPECTED,"The V5 master differs from the approved file."
    out.parent.mkdir(exist_ok=True,parents=True)
    scene=bpy.context.scene
    assert str(bpy.app.version_string).startswith("4.5.3") and scene.render.engine=="CYCLES"
    source_objects=tuple(scene.objects)
    matrices={o.name:tuple(tuple(float(v) for v in r) for r in o.matrix_world) for o in source_objects}
    arch=apply_architecture(scene)
    padded=apply_upholstery()
    routed_frames=apply_chair_frames()
    terrain=refine_landscape(scene)
    horizon=apply_horizon(scene)
    # A subset of the same mesh helpers used in V5; no source scene loads occur here.
    exec(compile((HERE/"geometry_helpers.py").read_text(),"geometry_helpers.py","exec"),globals())
    woodlight=next(m for m in bpy.data.materials if m.name.startswith("05 | Oiled ash"))
    linen=next(m for m in bpy.data.materials if m.name.startswith("06 | Oatmeal boucle"))
    sage=next(m for m in bpy.data.materials if m.name.startswith("07 | Sage linen"))
    exec(compile((HERE/"living_objects_v6.py").read_text(),"living_objects_v6.py","exec"),globals())
    bpy.context.view_layer.update()
    lived=check_support(_SW_LIVED_CHECKS,source_objects)
    light=apply_lighting_and_cameras(scene,validate=True)
    found=sum(1 for name,matrix in matrices.items() if bpy.data.objects.get(name) is not None and tuple(tuple(float(v) for v in r) for r in bpy.data.objects[name].matrix_world)==matrix)
    unchanged_structure=sum(1 for name,matrix in matrices.items() if (o:=bpy.data.objects.get(name)) and o.type=="MESH" and name.startswith(("L1 |","L2 |","L3 |","Fourteen-meter","Pavilion |")) and tuple(tuple(float(v) for v in r) for r in o.matrix_world)==matrix)
    external=[i.filepath for i in bpy.data.images if i.source=="FILE" and i.filepath and not i.packed_file and i.users>0]
    assert not external,external
    scene["project"]="STILLWATER HOUSE | VI · QUIET EVENING"
    scene["revision"]="V6"
    scene["source_v5_sha256"]=EXPECTED
    scene["scope"]="Blender appearance and detail revision; preserve approved layout. No browser or Unreal update."
    scene.render.filepath="//renders/"
    scene.render.image_settings.file_format="PNG"
    scene.render.image_settings.color_mode="RGB"
    scene.render.image_settings.color_depth="8"
    scene.cycles.device="CPU" # Editable anywhere; the explicit MoLab render driver selects the verified GPU.
    scene.cycles.samples=112
    scene.cycles.adaptive_threshold=.02
    scene.cycles.use_denoising=True
    scene.render.resolution_x=2160
    scene.render.resolution_y=1440
    scene.render.resolution_percentage=100
    camera=next(o for o in scene.objects if o.type=="CAMERA" and o.name.startswith("V6 | 01 |"))
    scene.camera=camera
    scene.view_settings.exposure=float(camera.get("v6_exposure",-.10))
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(out),compress=True)
    assert sha(original)==EXPECTED
    summary={"approved_master_sha256":EXPECTED,"blender":bpy.app.version_string,
        "output_file":out.name,"output_sha256":sha(out),"output_bytes":out.stat().st_size,
        "objects":len(scene.objects),"mesh_count":sum(o.type=="MESH" for o in scene.objects),
        "source_objects_same_transform":found,"stated_structure_same_transform":unchanged_structure,
        "external_images":external,"architecture":arch,"upholstery":padded,
        "landscape":terrain,"southern_ridges":horizon,"bentwood_frames":routed_frames,"lived_in":dict(lived,objects=len(_SW_LIVED_COLLECTION.objects)),"light":light}
    out.with_suffix(".receipt.json").write_text(json.dumps(summary,indent=2)+"\n")
    print("V6_READY",json.dumps({k:summary[k] for k in ("output_file","output_sha256","output_bytes","objects","mesh_count","lived_in","architecture")}),flush=True)

if __name__=="__main__":main()

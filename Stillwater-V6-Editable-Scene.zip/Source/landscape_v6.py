"""Refine the accepted V5 environment on a derived Blender scene, never the master."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import sys

import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree


def smooth(lo, hi, x):
    t=max(0.,min(1.,(x-lo)/(hi-lo)))
    return t*t*(3.-2.*t)


def mesh(name, verts, faces, mats, indices=None, soften=False):
    me=bpy.data.meshes.new(name)
    me.from_pydata(verts,[],faces);me.update()
    for m in mats:me.materials.append(m)
    if indices is not None:me.polygons.foreach_set('material_index',indices)
    if soften:
        for f in me.polygons:
            f.use_smooth=f.material_index!=0
    return me


class Shader:
    def __init__(self,name,rough=.86):
        self.m=bpy.data.materials.new(name);self.m.use_nodes=True
        self.n=self.m.node_tree.nodes;self.l=self.m.node_tree.links
        self.bs=self.n.get('Principled BSDF')
        self.bs.inputs['Roughness'].default_value=rough
        geo=self.n.new('ShaderNodeNewGeometry')
        self.p=geo.outputs['Position'];self.normal=geo.outputs['Normal']
    def set(self,sock,v):
        if isinstance(v,bpy.types.NodeSocket):self.l.new(v,sock)
        else:sock.default_value=v
    def math(self,op,a,b=None,clamp=False):
        n=self.n.new('ShaderNodeMath');n.operation=op;n.use_clamp=clamp
        self.set(n.inputs[0],a)
        if b is not None:self.set(n.inputs[1],b)
        return n.outputs[0]
    def v(self,operation,a,b):
        n=self.n.new('ShaderNodeVectorMath');n.operation=operation
        self.set(n.inputs[0],a);self.set(n.inputs[1],b)
        return n.outputs['Value' if operation in ('DOT_PRODUCT','DISTANCE') else 'Vector']
    def noise(self,scale,detail,axis=None):
        n=self.n.new('ShaderNodeTexNoise')
        self.set(n.inputs['Vector'],self.p if axis is None else axis)
        n.inputs['Scale'].default_value=scale;n.inputs['Detail'].default_value=detail;n.inputs['Roughness'].default_value=.69
        return n.outputs['Fac']
    def z(self,vec):
        n=self.n.new('ShaderNodeSeparateXYZ');self.l.new(vec,n.inputs[0]);return n.outputs['Z']
    def map(self,a,low,high,to_low,to_high):
        n=self.n.new('ShaderNodeMapRange');n.clamp=True;n.interpolation_type='SMOOTHERSTEP'
        self.set(n.inputs['Value'],a)
        for key,v in zip(('From Min','From Max','To Min','To Max'),(low,high,to_low,to_high)):
            n.inputs[key].default_value=v
        return n.outputs[0]
    def color(self,signal,stops):
        n=self.n.new('ShaderNodeValToRGB');r=n.color_ramp;r.interpolation='EASE'
        self.l.new(signal,n.inputs[0])
        for i,(p,c) in enumerate(stops):
            e=r.elements[0 if i==0 else -1] if i<2 else r.elements.new(p)
            e.position=p;e.color=(*c,1)
        return n.outputs[0]
    def mix(self,a,b,f):
        n=self.n.new('ShaderNodeMixRGB')
        self.set(n.inputs[0],f)
        self.set(n.inputs[1],a);self.set(n.inputs[2],b)
        return n.outputs[0]
    def bump(self,height,strength,distance):
        n=self.n.new('ShaderNodeBump');n.inputs['Strength'].default_value=strength
        n.inputs['Distance'].default_value=distance
        self.l.new(height,n.inputs['Height']);self.l.new(n.outputs[0],self.bs.inputs['Normal'])
    def finish(self,color,viewport):
        self.l.new(color,self.bs.inputs['Base Color']);self.m.diffuse_color=(*viewport,1);return self.m


def mountain_shader():
    s=Shader('V6 Mountain | shale, talus, chaparral and cool distance')
    rock=s.noise(.22,4.5)
    domain=s.v('MULTIPLY',s.p,(1.0,1.05,2.4))
    wear=s.noise(.65,4.0,domain);fine=s.noise(3.60,3,domain)
    # Elevated, steep faces expose fractured bedrock. Lower chaparral remains
    # irregular and follows cooler/gentler drainage areas rather than one tree line.
    slope=s.map(s.z(s.normal),.49,.93,.95,0.)
    high=s.map(s.z(s.p),6,54,.02,.78)
    faults=s.noise(.085,3.8)
    rough_mask=s.math('ADD',s.math('MAXIMUM',slope,high),s.map(faults,.18,.82,-.39,.34),True)
    green=s.color(rock,[(.17,(.021,.032,.015)),(.87,(.126,.139,.067)),(.53,(.056,.073,.032))])
    shale=s.color(wear,[(.19,(.066,.070,.065)),(.81,(.276,.236,.174)),(.49,(.145,.132,.105))])
    sand=s.color(fine,[(.17,(.117,.090,.060)),(.83,(.373,.309,.228)),(.49,(.228,.176,.122))])
    bedding=s.v('DOT_PRODUCT',s.p,(.135,-.086,.62))
    bent=s.math('ADD',bedding,s.math('ADD',s.math('MULTIPLY',faults,3.4),s.math('MULTIPLY',wear,1.6)))
    seam=s.math('PINGPONG',bent,1.95)
    seam_mix=s.math('MULTIPLY',s.map(seam,.48,1.84,.04,.64),s.map(rock,.22,.71,.10,.96))
    stone=s.mix(shale,sand,seam_mix)
    top=s.mix(green,stone,rough_mask)
    # A mild distance-weighted tint, not a fog plane or scene-wide volume.
    dist=s.v('DISTANCE',s.p,(39,-73,21))
    far=s.map(dist,130,610,0,.23)
    top=s.mix(top,(.157,.206,.229,1),far)
    s.bs.inputs['Emission Color'].default_value=(.222,.289,.315,1)
    s.set(s.bs.inputs['Emission Strength'],s.map(dist,205,670,0,.045))
    ridge=s.math('MULTIPLY',s.math('MULTIPLY',seam,rough_mask),.19)
    detail=s.math('ADD',s.math('MULTIPLY',fine,.66),ridge)
    s.bump(detail,.31,.21)
    return s.finish(top,(.15,.132,.103))


def lawn_shader():
    s=Shader('V6 Grounds | cool green fescue with fine dry tips',.92)
    slow=s.noise(.45,3.5);middle=s.noise(5.4,3.2)
    canopy=s.math('ADD',s.math('MULTIPLY',slow,.73),s.math('MULTIPLY',middle,.27))
    colors=s.color(canopy,[(.16,(.022,.037,.008)),(.85,(.139,.171,.046)),(.50,(.065,.091,.021))])
    # In-plane mottled leaf blades and sub-centimetre tips for dolly closeups.
    tiny=s.noise(89.,2.0,s.v('MULTIPLY',s.p,(.81,1.17,.58)))
    s.bump(tiny,.24,.021)
    return s.finish(colors,(.066,.093,.022))


def foliage_shaders():
    palettes=[
        ((.042,.025,.012),(.116,.071,.037)),
        ((.013,.030,.014),(.040,.069,.033)),
        ((.021,.051,.031),(.078,.131,.065)),
        ((.029,.061,.027),(.111,.156,.067)),
        ((.049,.078,.021),(.147,.182,.076)),
    ]
    mats=[]
    for i,(low,high) in enumerate(palettes):
        sh=Shader(f'V6 Forest | {"fissured bark" if i==0 else "needle pigments "+str(i)}',.90 if i==0 else .82)
        broad=sh.noise(4.7 if i else 13.0,3.2)
        color=sh.color(broad,[(.20,low),(.80,high)])
        sh.bump(sh.noise(38.,2.2),.18 if i else .29,.013 if i else .021)
        mats.append(sh.finish(color,tuple((a+b)/2 for a,b in zip(low,high))))
    return mats


def make_tree(seed,lod,mats):
    rng=random.Random(seed)
    verts=[];faces=[];ids=[]
    up=Vector((0,0,1))
    lean=Vector((rng.uniform(-.028,.033),rng.uniform(-.032,.039),0))
    width=rng.uniform(.134,.173)*(1.12 if seed%3==0 else .94 if seed%3==1 else 1.)
    palette=[1,1,2,2,2,3,3,4] if seed%3 else [1,2,2,3,3,3,4]

    def poly(p,mi):
        j=len(verts);verts.extend(p);faces.append(tuple(range(j,len(verts))));ids.append(mi)
    def twig(a,b,r1,r2,n=5):
        ax=(b-a).normalized()
        e=ax.cross(up)
        e=Vector((1,0,0)) if e.length<.01 else e.normalized()
        f=ax.cross(e)
        st=len(verts)
        for p,r in ((a,r1),(b,r2)):
            verts.extend(p+r*(math.cos(k*math.tau/n)*e+math.sin(k*math.tau/n)*f) for k in range(n))
        for j in range(n):
            k=(j+1)%n
            faces.append((st+j,st+k,st+k+n,st+j+n));ids.append(0)
    def leaf(p,d,a,l,w,mi):
        q=p+d*l
        rib=p.lerp(q,.55)
        poly((p,rib+a*w,q,rib-a*w+up*(w*.32)),mi)
    def plume(p,d,l,w,detail):
        a=Vector((-d.y,d.x,0)).normalized()
        d=(d+up*rng.uniform(-.17,.33)).normalized()
        p1=p+d*l*.43
        p2=p+d*l*.75
        q=p+d*l
        t1=up*w*.64
        t2=up*w*.51
        # Tapered, rounded twig envelope. Cross-sprays are staggered radially,
        # not concentric cones or repeated horizontal whorls.
        for u,lo,hi in [(a,0.,1.),(up,.16,.88),(a*.59+up*.74,.21,.78)]:
            k1=p.lerp(q,lo);k2=p.lerp(q,hi)
            poly((k1,p1+u*w*.70,k2,p2-u*w*.41),rng.choice(palette))
            poly((k1,p1-u*w*.69,k2,p2+u*w*.39),rng.choice(palette))
        count=6 if detail else 3 if lod else 1
        for k in range(count):
            t=(k+.7)/(count+.5)
            b=p+d*l*t
            for side in [-1,1]:
                le=l*rng.uniform(.21,.32)*(1.-.66*t)
                dr=(d*.71+a*side*rng.uniform(.4,.91)+up*rng.uniform(-.34,.42)).normalized()
                leaf(b,dr,a,le,w*rng.uniform(.05,.14),rng.choice(palette))
                if detail:
                    leaf(b+d*l*.12,(dr*.8+up*rng.uniform(.12,.48)).normalized(),a,le*.83,w*.10,rng.choice(palette))
        if detail:
            for sign in [-1,1]:
                leaf(p1+t1*.47,(d+a*sign*.69+up*.33).normalized(),a,l*.29,w*.115,rng.choice(palette))
                leaf(p2+t2*.47,(d+a*sign*.51-up*.24).normalized(),a,l*.20,w*.10,rng.choice(palette))

    old=Vector((0,0,0))
    for i in range(1,10):
        z=i/9
        to=lean*z*z+up*z
        twig(old,to,.017*(1-(i-1)/9)**1.18+.0005,.017*(1-z)**1.18+.0005,7 if lod>1 else 5)
        old=to
    levels=14 if lod>1 else 11 if lod else 8
    bottom=rng.uniform(.12,.24)
    for i in range(levels):
        z=bottom+(.973-bottom)*i/(levels-1)
        phi=i*2.39996+rng.uniform(-.35,.39)
        n=6 if lod>1 and z<.68 else 5 if lod else 4
        for j in range(n):
            if rng.random()<.080:continue
            a=phi+j*math.tau/n+rng.uniform(-.28,.25)
            dr=Vector((math.cos(a),math.sin(a),0))
            left=Vector((-dr.y,dr.x,0))
            zz=z+rng.uniform(-.020,.024)
            r0=lean*zz*zz+up*zz
            l=width*(1.-z)**.57*rng.uniform(.73,1.21)*(1.-.12*math.sin(a*2.+seed))
            mid=r0+dr*l*.51-up*l*rng.uniform(.08,.21)
            tip=r0+dr*l+up*l*rng.uniform(-.05,.20)
            if lod:
                twig(r0,mid,.0042*(1-z)+.0008,.0026*(1-z)+.0005,5)
                twig(mid,tip,.0026*(1-z)+.0005,.00045,5)
            splays=5 if lod>1 else 3 if lod else 2
            for k in range(splays):
                t=.22+k*.61/max(splays-1,1)
                p=r0.lerp(tip,t)-up*l*.13*math.sin(math.pi*t)
                for sign in (-1,1):
                    tumble=rng.uniform(.48,.93)
                    d=(dr*(.83+.26*t)+left*sign*tumble).normalized()
                    length=l*(.50-.21*t)*rng.uniform(.72,1.24)
                    plume(p,d,length,length*rng.uniform(.16,.25),lod>1)
            plume(mid,dr,l*.58,l*.10,lod>1)
            plume(r0.lerp(tip,.77),dr,l*.31,l*.064,lod>1)
        # Irregular short interior shoots partially cover trunk gaps.
        for k in range(3):
            a=phi+k*2.094
            dr=Vector((math.cos(a),math.sin(a),0))
            p=lean*z*z+up*(z+.015)
            l=width*(1.-z)**.69*rng.uniform(.35,.61)
            plume(p,dr,l,l*.29,lod>1)
    for i in range(5):
        a=i*2.399;r=.026-i*.0025
        plume(lean*.99+up*(.956+i*.009),Vector((math.cos(a),math.sin(a),0)),r,r*.24,lod>1)
    return mesh(f'V6 Pinus crown | family {seed} LOD{lod}',verts,faces,mats,ids,True)


def grass_ribbons(lawn,group,rng):
    verts=[];faces=[];ids=[]
    world=[lawn.matrix_world@v.co for v in lawn.data.vertices]
    outline=[world[i] for i in lawn.data.polygons[0].vertices]
    xa,xb=min(v.x for v in world),max(v.x for v in world)
    ya,yb=min(v.y for v in world),max(v.y for v in world)
    z=sum(v.z for v in world)/len(world)
    def inside(x,y):
        count=0
        for a,b in zip(outline,outline[1:]+outline[:1]):
            if (a.y>y)!=(b.y>y) and x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x:
                count+=1
        return count%2==1
    mats=[]
    for i,c in enumerate([(.048,.076,.018),(.069,.099,.025),(.10,.125,.031),(.143,.153,.047),(.073,.102,.021)]):
        s=Shader('V6 Turf | fescue blade '+str(i),.91)
        s.bs.inputs['Base Color'].default_value=(*c,1);s.m.diffuse_color=(*c,1);mats.append(s.m)
    blade_count=0
    for j in range(5300):
        x=rng.uniform(xa,xb);y=rng.uniform(ya,yb)
        if not inside(x,y):continue
        density=(math.sin(.74*x+.52*y)+math.cos(y*1.24-.23*x))*.22+.69
        if rng.random()>density:continue
        for _ in range(rng.choice((3,4,5))):
            px=x+rng.uniform(-.070,.070);py=y+rng.uniform(-.064,.064)
            if not inside(px,py):continue
            a=rng.uniform(0,math.tau);h=rng.uniform(.016,.057)
            dx,dy=math.cos(a),math.sin(a);w=rng.uniform(.0012,.0024);bend=h*rng.uniform(.23,.67)
            st=len(verts)
            verts.extend([(px-dy*w,py+dx*w,z+.0008),(px+dy*w,py-dx*w,z+.0008),
                          (px+bend*.40*dx+dy*w*.71,py+bend*.40*dy-dx*w*.71,z+h*.59),
                          (px+bend*.40*dx-dy*w*.71,py+bend*.40*dy+dx*w*.71,z+h*.59),
                          (px+bend*dx,py+bend*dy,z+h)])
            faces.extend(((st,st+1,st+2,st+3),(st+3,st+2,st+4)))
            idx=rng.choice((0,1,1,2,2,3,4,4));ids.extend((idx,idx));blade_count+=1
    m=mesh('V6 short fescue ribbons',verts,faces,mats,ids)
    ob=bpy.data.objects.new('V6 Lawn | individually tapered short blades',m);group.objects.link(ob)
    return blade_count


def refine_landscape(scene=None):
    scene=scene or bpy.context.scene
    if scene.get('stillwater_v6_landscape_revision') is not None:
        raise RuntimeError('V6 landscape is already present; start from an unmodified V5-derived scene.')
    terrain=bpy.data.objects.get('Mountain | Continuous graded land, ridges and valley')
    lawn=bpy.data.objects.get('Lower lawn | clipped fescue clearing')
    yard=bpy.data.objects.get('Summit clearing | precise excavated garden grade')
    source_trees=[o for o in scene.objects if o.type=='MESH' and o.name.startswith('Viridian spruce ')]
    if not (terrain and lawn and yard and len(source_trees)>=850):
        raise RuntimeError('Expected accepted Stillwater V5 terrain, lawn and source forest geometry.')
    protected=[obj for collection in scene.collection.children
               if collection.name.startswith(('V5 | L','22 Upper','19 Garden and arrival','18 Cliff terraces','05 Water garden','23 Balcony'))
               for obj in collection.objects if obj.type=='MESH']
    def signature(obj):
        return (obj.name,obj.data.as_pointer(),len(obj.data.vertices),tuple(tuple(row) for row in obj.matrix_world),
                tuple(m.name if m else '' for m in obj.data.materials))
    protected_before=[signature(o) for o in protected]
    group=bpy.data.collections.new('V6 Landscape | fescue and distant forest');scene.collection.children.link(group)
    # Keep all pad, ramps, retaining structures and adjacent forest roots
    # untampered. Only distant vertices move, and only by sub-metre detail.
    changed=0;max_displace=0.
    terrain.data=terrain.data.copy()
    normal_z=[v.normal.z for v in terrain.data.vertices]
    for vv,nz in zip(terrain.data.vertices,normal_z):
        x,y,z=vv.co
        if y<108 or z< -19:continue
        grade=1.-max(0.,nz)
        mask=smooth(108,157,y)*smooth(-19,8,z)*smooth(.012,.45,grade)
        a=.33*x-.20*y+.52*math.sin(x*.08+y*.06)
        b=.16*x+.24*y+.91*math.sin(y*.084)
        c=.77*x-.43*y
        cut=(.52*math.sin(a)**3+.43*math.sin(b)**3+.18*math.sin(c))
        dz=mask*cut
        if abs(dz)>.002:
            vv.co.z+=dz;changed+=1;max_displace=max(max_displace,abs(dz))
    terrain.data.update();terrain.data.materials[0]=mountain_shader()
    lawn.data=lawn.data.copy();lawn.data.materials[0]=lawn_shader()
    rng=random.Random(770531)
    blades=grass_ribbons(lawn,group,rng)
    mats=foliage_shaders()
    asset_map={}
    swapped=0;recolored_far=0;old_eval=sum(len(o.data.polygons) for o in source_trees)
    for o in source_trees:
        source=o.data
        if source.name not in asset_map:
            parts=source.name.replace('•',' ').split()
            try:seed=int(parts[-1]);lod=int(parts[-2])
            except (ValueError,IndexError):seed,lod=527+len(asset_map)*17,0
            if lod==0:
                # At pixel-scale distances retain the far mesh topology and its cheap
                # crown silhouettes. Near and middle crowns receive the new boughs.
                copy=source.copy();copy.name=f'V6 distant inherited low-poly crown | {seed}'
                for i in range(len(copy.materials)):
                    copy.materials[i]=mats[min(i,len(mats)-1)]
                asset_map[source.name]=(copy,lod)
            else:
                asset_map[source.name]=(make_tree(seed,lod,mats),lod)
        o.data,lod=asset_map[source.name]
        if lod:swapped+=1
        else:recolored_far+=1
    # Rocky foreground is free of new plants. Small backdrop trees are grounded
    # by the edited mountain mesh, with patches controlled by elevation and grade.
    bvh=BVHTree.FromPolygons([tuple(v.co) for v in terrain.data.vertices],
                            [tuple(f.vertices) for f in terrain.data.polygons])
    scatter=[make_tree(k,0,mats) for k in (1117,1229,1351)]
    extras=0
    for ix in range(-252,74,4):
        for iy in range(142,251,4):
            x=ix+rng.uniform(-1.49,1.43);y=iy+rng.uniform(-1.48,1.46)
            density=.34+.16*math.sin(.113*x+.115*y)+.13*math.cos(.067*x-.16*y)
            if rng.random()>density:continue
            p,n,_,_=bvh.ray_cast(Vector((x,y,115)),Vector((0,0,-1)),170)
            if p is None or n.z<.83 or p.z>17.5 or p.z<-28.0:continue
            if abs(x+1.17*y+25)<24 and p.z>9:continue
            scale=rng.uniform(3.05,7.1)*(.84+.16*(1-smooth(0,17.5,p.z)))
            ob=bpy.data.objects.new(f'V6 distant evergreen {extras:03d}',rng.choice(scatter))
            group.objects.link(ob);ob.location=(x,y,p.z-.11)
            stretch=rng.uniform(.77,1.16);ob.scale=(scale*stretch,scale*stretch,scale)
            ob.rotation_euler=(rng.uniform(-.025,.025),rng.uniform(-.028,.028),rng.uniform(0,math.tau))
            extras+=1
            if extras>=250:break
        if extras>=250:break
    report=dict(terrain_vertices_refined=changed,maximum_vertical_vertex_change_m=round(max_displace,4),
                near_and_mid_tree_crowns_rebuilt=swapped,distant_existing_crowns_recolored=recolored_far,
                linked_prototypes=len(asset_map),mid_distant_trees_added=extras,
                lawn_blades=blades,protected_structural_meshes=len(protected),
                source_evaluated_forest_faces=old_eval,
                resulting_evaluated_forest_faces=sum(len(o.data.polygons) for o in source_trees)+
                   sum(len(o.data.polygons) for o in group.objects if o.name.startswith('V6 distant evergreen')),
                source_tree_positions_and_scales_retained=True)
    assert [signature(o) for o in protected]==protected_before,'Approved structural or circulation meshes changed.'
    scene['stillwater_v6_landscape_revision']='V6 geology, conifer crown diversity and bounded lawn refinement'
    return report


def main(argv):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--report',type=Path)
    args=p.parse_args(argv)
    src=Path(bpy.data.filepath).resolve();out=args.output.resolve()
    if not src.is_file() or out==src or out.name=='Stillwater-House-V5.blend':
        raise ValueError('Open accepted V5 as input and save only to a distinct V6 filename.')
    if bpy.context.scene.get('revision')!='V5':raise ValueError('Expected accepted V5 as the source.')
    report=refine_landscape()
    report['source_sha256']=hashlib.sha256(src.read_bytes()).hexdigest()
    report['authoring_blender']=bpy.app.version_string
    out.parent.mkdir(parents=True,exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(out),compress=True)
    assert hashlib.sha256(src.read_bytes()).hexdigest()==report['source_sha256']
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2)+'\n')
    print('V6_LANDSCAPE_READY',json.dumps(report),flush=True)


if __name__=='__main__':
    main(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])

"""Editable Stillwater V6 sunset lighting and editorial cameras (Blender 4.5).

Load a V5-derived scene and call apply_lighting_and_cameras(). No rendering,
external textures, or changes to architectural geometry are performed here.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

LIGHT_COLLECTION = "V6 | evening luminaires"
CAMERA_COLLECTION = "V6 | editorial cameras"
PREFIX = "V6 | "
CAMERAS = (
    dict(key="01", name="01 | Sunset estate", source="01 | Golden hour estate",
         note="Preserve the accepted distant mountain and sunset silhouette.", exposure=-.10),
    dict(key="02", name="02 | Entry to living and dining", loc=(.04,7.87,1.91),
         target=(-.82,1.8,1.61), lens=22, shift=0, exposure=.15,
         note="Eye-height view through the arrival gallery toward the dining table, living textile, and glazing."),
    dict(key="03", name="03 | Travertine and upholstery", loc=(-6.16,3.64,1.49),
         target=(-4.75,2.15,.94), lens=58, shift=.015, aperture=7.1, exposure=.05,
         note="Low editorial detail: handthrown vessel, travertine edge, books and upholstery behind."),
    dict(key="04", name="04 | Island ceramics", loc=(1.10,3.54,1.87),
         target=(2.89,1.65,1.43), lens=44, shift=0, aperture=8.0, exposure=.04,
         note="Diagonal kitchen island portrait, with the basalt top, pale ceramics and bronze faucet in frame."),
    dict(key="05", name="05 | Pool terrace at dusk", loc=(-6.9,-16.8,1.92),
         target=(3.1,-7.55,2.05), lens=29, shift=.018, exposure=-.08,
         note="Walk-height exterior countershot: pool and terrace lead toward the warm house."),
)
WINDOWS = (
    ("Living | painted sky through bay 3", (-5.87,-1.04,2.03), (-5.67,3.13,1.27), 2.65,1.77,30, (.79,.88,1.0)),
    ("Dining | evening sky through bay 4", (-1.71,-1.04,2.04), (-1.65,3.28,1.35), 2.65,1.71,33, (.81,.90,1.0)),
    ("Kitchen | evening sky through bay 5", (2.62,-1.04,2.05), (2.83,3.58,1.32), 2.72,1.72,31, (.80,.89,1.0)),
)
# Existing V5 meshes, world-space positions from the evaluated V5 model.
CAMERA_ANCHORS = {
    "02": (("Living vessel",(-4.62,2.28,.945),("Living table still life",)),
           ("Dining top",(-1.23,1.76,1.1895),("Dining | oval-edged eight-seat table","Dining | centerpiece")),
           ("Living cushion",(-5.4925,.455,.98),("Living | wool sectional",))),
    "03": (("Living vessel",(-4.62,2.28,.945),("Living table still life","V6 |")),
           ("Travertine top",(-4.78,2.18,.8325),("Living | long travertine cocktail","Living table still life","V6 |"))),
    "04": (("Island top",(2.91,1.67,1.354),("Kitchen | walnut-front island","V6 |")),
           ("Ceramic staging surface",(2.8,1.84,1.355),("Kitchen | walnut-front island","V6 |")),
           ("Bronze faucet",(3.93,1.87,1.647),("Kitchen | bronze faucet","Kitchen | over-sink nose"))),
    "05": (("Pool water",(2.4,-11.84,-.06),("Fourteen-meter swimming pool",)),
           ("Glazing",(2.2,-.70,1.86),("L1 | garden slider bay 5",))),
}


def collection(scene, name):
    c = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    if c.name not in scene.collection.children:
        scene.collection.children.link(c)
    return c


def point(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()


def pair(c, name, kind):
    obj = bpy.data.objects.get(name)
    if obj is None:
        data = (bpy.data.lights if kind == "AREA" else bpy.data.cameras).new(
            name, **({"type": "AREA"} if kind == "AREA" else {}))
        obj = bpy.data.objects.new(name, data)
        c.objects.link(obj)
    elif obj.name not in c.objects:
        c.objects.link(obj)
    return obj


def soft_window(c, spec):
    label, pos, target, width, height, energy, rgb = spec
    obj = pair(c, PREFIX + label, "AREA")
    obj.location = pos
    point(obj, target)
    data = obj.data
    data.shape, data.size, data.size_y = "RECTANGLE", width, height
    data.energy, data.color, data.spread = energy, rgb, math.radians(150)
    data.normalize = True
    data.specular_factor = .16
    obj.visible_camera = False
    obj.visible_glossy = False
    obj.visible_transmission = False
    obj["v6_role"] = "Broad dusk skylight proxy, not a visible panel or direct sun source"
    return obj


def tune_existing(scene):
    authored = (
        ("Terrace soft fill", 56., (1.,.88,.75), None, None),
        ("Dining | warm bronze pendant | table light", 17., (1.,.80,.61), .23, 112),
        ("Kitchen | smaller island pendant | table light", 21., (1.,.84,.68), .23, 115),
        ("Entry gallery | landing light", 32., (1.,.88,.75), None, 140),
        ("Garden guest | warm interior wash", 37., (1.,.88,.76), None, 140),
        ("Garden guest bath | small ceiling wash", 18., (1.,.88,.78), None, 135),
        ("Flex gym | warm ceiling fill", 29., (1.,.89,.79), None, 145),
        ("Garden wayfinder | discreet ground wash", 7.2, (1.,.78,.58), None, 125),
        ("Fire court | ember bounce", 46., (1.,.48,.23), None, 125),
        ("Pavilion | warm pendant light", 52., (1.,.77,.56), None, 115),
        ("Pool wall | underwater glow", 17.5, (.68,.87,1.), None, 128),
    )
    fills = (35., 40., 32.)
    changed = []
    for obj in scene.objects:
        if obj.type != "LIGHT" or obj.data.type != "AREA":
            continue
        data = obj.data
        name = obj.name
        setup = next((record[1:] for record in authored if name.startswith(record[0])), None)
        if name.startswith("Garden level | indirect interior fill"):
            idx = int(name.rsplit(".",1)[1]) if "." in name else 0
            setup = (fills[min(idx,len(fills)-1)], (1.,.90,.79), None, 145)
        elif name.startswith(("L2 | interior warm light","L3 | broad atelier luminaire",
                              "Roof lounge | soft canopy wash","Stair 01 | garden to upper residence",
                              "Stair 02 | upper residence to atelier")):
            authored_watts = obj.get("v6_before_watts", data.energy)
            setup = (authored_watts*.74, (1.,.84,.68), None, 142)
        if setup is None:
            continue
        watts, color, size, spread = setup
        if "v6_before_watts" not in obj:
            obj["v6_before_watts"] = data.energy
        data.energy, data.color, data.normalize = watts, color, True
        if size is not None: data.size = size
        if spread is not None: data.spread = math.radians(spread)
        if "table light" in name:
            data.specular_factor = .26
            obj.visible_glossy = True
        changed.append(dict(name=name, watts=round(watts,2), rgb=color))
    emitter = bpy.data.materials.get("23 | Warm 2700 K emitter")
    if emitter and emitter.use_nodes:
        bs = next((n for n in emitter.node_tree.nodes if n.type=="BSDF_PRINCIPLED"),None)
        if bs:
            bs.inputs["Emission Color"].default_value = (1.,.66,.36,1.)
            bs.inputs["Emission Strength"].default_value = 2.6
    return changed


def cameras(scene):
    c = collection(scene, CAMERA_COLLECTION)
    result = {}
    for spec in CAMERAS:
        name = PREFIX + spec["name"]
        camera = pair(c, name, "CAMERA")
        data = camera.data
        if spec.get("source"):
            ref = bpy.data.objects.get(spec["source"])
            if ref is None or ref.type!="CAMERA":
                raise RuntimeError("The accepted V5 estate camera is missing.")
            camera.matrix_world = ref.matrix_world.copy()
            data.lens, data.sensor_width = ref.data.lens, ref.data.sensor_width
            data.sensor_fit = ref.data.sensor_fit
            data.shift_x, data.shift_y = ref.data.shift_x, ref.data.shift_y
            data.clip_start, data.clip_end = ref.data.clip_start, ref.data.clip_end
        else:
            camera.location = spec["loc"]
            point(camera, spec["target"])
            data.type, data.lens = "PERSP", spec["lens"]
            data.sensor_fit, data.sensor_width = "HORIZONTAL", 36.
            data.shift_x, data.shift_y = 0., spec["shift"]
            data.clip_start, data.clip_end = .055, 2300
            data.dof.use_dof = "aperture" in spec
            if data.dof.use_dof:
                data.dof.focus_distance = (camera.location - Vector(spec["target"])).length
                data.dof.aperture_fstop = spec["aperture"]
                data.dof.aperture_blades = 9
        camera["v6_exposure"] = spec["exposure"] # Optional per-shot render override; not a driver.
        camera["v6_framing"] = spec["note"]
        result[spec["key"]] = camera
    return result


def sightline(scene,dg,a,b,ignore_panes=False):
    p, target = Vector(a), Vector(b)
    d = (target-p).normalized()
    skipped=[]
    for _ in range(18):
        limit = (target-p).dot(d)
        if limit<1e-4: break
        hit,where,_normal,_index,obj,_matrix = scene.ray_cast(dg,p,d,distance=limit+.035)
        if not hit: break
        if ignore_panes and ("low iron pane" in obj.name.lower() or "fixed glass" in obj.name.lower()):
            skipped.append(obj.name)
            p=where+d*.011
            continue
        return {"hit":obj.name,"through":skipped}
    return {"hit":None,"through":skipped}


def sightline_receipt(scene, result, windows):
    dg=bpy.context.evaluated_depsgraph_get()
    checks={}
    for key,camera in result.items():
        origin=camera.matrix_world.translation.copy()
        fwd=camera.matrix_world.to_quaternion() @ Vector((0,0,-1))
        row={"name":camera.name,"lens_mm":round(camera.data.lens,2),"location":[round(v,4) for v in origin],
             "exposure":round(camera["v6_exposure"],2),
             "front_clearance_0p33m":sightline(scene,dg,origin,origin+fwd*.33)["hit"] is None,
             "subjects":[]}
        for name,target,accepted in CAMERA_ANCHORS.get(key,()):
            nd=world_to_camera_view(scene,camera,Vector(target))
            hit=sightline(scene,dg,origin,target)
            row["subjects"].append(dict(subject=name, uv=[round(nd.x,3),round(nd.y,3)],
                 in_frame=nd.z>0 and .04<nd.x<.96 and .05<nd.y<.95,
                 saw=hit["hit"], matches=bool(hit["hit"] and hit["hit"].startswith(accepted))))
        checks[key]=row
    sky_rays=[]
    for obj,spec in zip(windows,WINDOWS):
        target=Vector(spec[2])
        # Confirm the direction crosses a window opening, not a wall pier.
        across=obj.location.lerp(target,.31)
        hit=sightline(scene,dg,obj.location,across,ignore_panes=True)
        sky_rays.append(dict(light=obj.name, y_crossing=round(across.y,2), obstruction=hit["hit"], panes=hit["through"]))
    return checks,sky_rays


def apply_lighting_and_cameras(scene=None, validate=True):
    scene=scene or bpy.context.scene
    sun=bpy.data.objects.get("Golden hour | low direct sunlight")
    if sun is None or sun.type!="LIGHT" or not scene.world or not scene.world.use_nodes:
        raise RuntimeError("The agreed V5 sun and node-based world are required.")
    appearance=scene.view_settings
    appearance.view_transform = "AgX"
    appearance.look = "AgX - Medium High Contrast"
    appearance.exposure, appearance.gamma = -.10, 1.
    glare_muted=[]
    if scene.node_tree:
        for node in scene.node_tree.nodes:
            if node.type == "GLARE":
                node.mute=True
                glare_muted.append(node.name)
    if scene.render.engine=="CYCLES":
        scene.cycles.diffuse_bounces=max(scene.cycles.diffuse_bounces,5)
        scene.cycles.glossy_bounces=max(scene.cycles.glossy_bounces,5)
        scene.cycles.transmission_bounces=max(scene.cycles.transmission_bounces,8)
        scene.cycles.max_bounces=max(scene.cycles.max_bounces,11)
    authored=tune_existing(scene)
    lights=collection(scene,LIGHT_COLLECTION)
    windows=[soft_window(lights,spec) for spec in WINDOWS]
    order=cameras(scene)
    scene.camera=order["01"]
    scene["v6_exposure_note"]="AgX / exposure -0.10 EV baseline; each V6 camera has a reviewed starting exposure in custom properties."
    scene["v6_lighting_note"]="V5 world/sun preserved; local 3 broad window proxies and existing practical luminaires; glare muted."
    bpy.context.view_layer.update()
    checks,sky_rays=sightline_receipt(scene,order,windows) if validate else ({},{})
    return {
      "blender":bpy.app.version_string,
      "sun":{"name":sun.name,"watts_per_square_meter":sun.data.energy,"world":scene.world.name},
      "view":dict(transform=appearance.view_transform,look=appearance.look,exposure=round(appearance.exposure,2),muted_glare=glare_muted),
      "camera_order":[c.name for c in order.values()],
      "camera_sightlines":checks,"window_light_rays":sky_rays,"tuned_areas":authored,
    }


def main():
    args=argparse.ArgumentParser(description=__doc__)
    args.add_argument("--save", type=Path)
    args.add_argument("--receipt", type=Path)
    opts=args.parse_args(sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else [])
    if opts.save:
        original=Path(bpy.data.filepath).resolve() if bpy.data.filepath else None
        if original==opts.save.resolve() or opts.save.name.lower()=="stillwater-house-v5.blend":
            raise SystemExit("Refusing to overwrite the loaded scene or the V5 master.")
    receipt=apply_lighting_and_cameras()
    if opts.receipt:
        opts.receipt.write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    if opts.save:
        bpy.ops.wm.save_as_mainfile(filepath=str(opts.save.resolve()),compress=True)
    print("STILLWATER_V6_LIGHTING_READY",json.dumps(receipt,separators=(",",":")))


if __name__ == "__main__":
    main()

"""Opt-in southern foothills for V6, beyond the approved estate terrain."""
import math

import bpy

GROUP='V6 Landscape | southern horizon'

# Irregular survey-style ridge control points, not sinusoidal skyline cards.
# Each tuple is crest (Blender east X, south Y, up Z) in metres.
RIDGES=(
 dict(label='01 | Foremost chaparral foothills',xspan=(-835,740),yspan=(-177,-665),
    basin=-49,step=8,seed=11,
    crest=((-835,-380,0),(-692,-399,17),(-563,-421,23),(-447,-418,17),(-369,-434,28),
      (-298,-444,19),(-223,-426,34),(-166,-438,28),(-113,-445,31),(-49,-416,39),
      (15,-435,25),(77,-448,23),(124,-450,31),(205,-463,38),(266,-431,27),
      (314,-407,16),(397,-397,26),(447,-389,18),(540,-415,18),(740,-450,1)),
    forest=((.066,.076,.047),(.171,.171,.115)),stone=((.109,.104,.077),(.234,.207,.147)),
    air=(.244,.279,.272),air_share=.18),
 dict(label='02 | Dissected middle range',xspan=(-1355,1225),yspan=(-535,-1025),
    basin=-58,step=11,seed=19,
    crest=((-1355,-688,9),(-1120,-737,34),(-895,-759,56),(-735,-708,46),(-629,-728,65),
      (-504,-759,73),(-401,-740,54),(-307,-747,57),(-242,-782,77),(-119,-790,61),
      (-31,-761,55),(65,-777,69),(144,-788,83),(263,-757,59),(352,-776,68),
      (464,-744,65),(570,-727,65),(691,-749,48),(831,-695,41),(1225,-723,6)),
    forest=((.090,.111,.096),(.182,.204,.173)),stone=((.134,.147,.130),(.225,.226,.194)),
    air=(.284,.329,.334),air_share=.24),
 dict(label='03 | Outer blue-grey watershed',xspan=(-1815,1620),yspan=(-875,-1490),
    basin=-73,step=15,seed=27,
    crest=((-1815,-1171,19),(-1470,-1212,57),(-1143,-1190,92),(-954,-1212,107),
      (-807,-1196,93),(-665,-1234,111),(-501,-1250,103),(-393,-1220,133),
      (-267,-1190,112),(-145,-1208,96),(-57,-1189,127),(82,-1210,146),(180,-1241,119),
      (299,-1247,111),(424,-1229,119),(586,-1217,97),(752,-1191,115),(896,-1168,79),
      (1086,-1206,62),(1620,-1231,16)),
    forest=((.134,.177,.183),(.212,.253,.255)),stone=((.150,.181,.183),(.234,.262,.259)),
    air=(.320,.362,.371),air_share=.31),
)


def _smooth(a,b,v):
    t=max(0.,min(1.,(v-a)/(b-a)))
    return t*t*(3.-2.*t)


def _interp(knots,x):
    """Nonuniform Hermite skyline with locally limited tangents."""
    i=next((j for j in range(len(knots)-1) if x<=knots[j+1][0]),len(knots)-2)
    a,b=knots[i],knots[i+1]
    aa,bb=knots[max(0,i-1)],knots[min(i+2,len(knots)-1)]
    span=b[0]-a[0]
    t=max(0.,min(1.,(x-a[0])/span))
    z=[]
    for k in (1,2):
        run=(b[k]-a[k])/span
        da=(b[k]-aa[k])/(b[0]-aa[0]);db=(bb[k]-a[k])/(bb[0]-a[0])
        if not run:da=db=0.
        else:
            da=math.copysign(min(abs(da),2.*abs(run)),run) if da*run>0 else 0.
            db=math.copysign(min(abs(db),2.*abs(run)),run) if db*run>0 else 0.
        z.append((2*t**3-3*t*t+1)*a[k]+(t**3-2*t*t+t)*span*da+
                 (-2*t**3+3*t*t)*b[k]+(t**3-t*t)*span*db)
    return z


def _height(x,y,cy,crest,spec):
    v=y-cy
    # A sharper north-facing cut falls toward the viewer; the reverse
    # backslope and spur widths vary independently along the watershed.
    width=(106 if v>=0 else 141)+(spec['seed']-11)*3.4
    width*=1.+.12*math.sin(x*.0058+spec['seed'])+.081*math.cos(x*.014)
    q=abs(v)/width
    crest_shape=math.exp(-q**1.57)
    low=spec['basin']+.013*x+5.7*math.sin(x*.008+y*.011)
    wash_phase=(x+.22*v+.0012*v*v)*(.047-.00045*spec['seed'])
    # Incisions disappear both at the ridge crest and on the valley floor.
    wash=(_smooth(.07,.43,q)*(1.-_smooth(.91,2.1,q))*
        (5.3*max(0,math.sin(wash_phase+.61*math.cos(.024*y)))**2+
         4.1*max(0,math.cos(.48*wash_phase+.012*x+spec['seed']))**3))
    ribs=(2.6*math.sin(.064*x+.052*y+math.sin(.031*x))+
          1.3*math.sin(.133*x-.098*y+spec['seed'])+
          .58*math.sin(.29*x-.22*y))
    return low+(crest-low)*crest_shape-wash+ribs*(.23+.57*crest_shape)


def _ridge_material(spec):
    m=bpy.data.materials.new('V6 Farland | '+spec['label']);m.use_nodes=True
    n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF')
    p.inputs['Roughness'].default_value=.97
    geo=n.new('ShaderNodeNewGeometry')
    tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=.028;tex.inputs['Detail'].default_value=5.
    tex.inputs['Roughness'].default_value=.72;l.new(geo.outputs['Position'],tex.inputs['Vector'])
    cols=[]
    for key in ('forest','stone'):
        r=n.new('ShaderNodeValToRGB')
        r.color_ramp.elements[0].position=.18;r.color_ramp.elements[0].color=(*spec[key][0],1)
        r.color_ramp.elements[1].position=.83;r.color_ramp.elements[1].color=(*spec[key][1],1)
        l.new(tex.outputs['Fac'],r.inputs[0]);cols.append(r.outputs[0])
    z=n.new('ShaderNodeSeparateXYZ');l.new(geo.outputs['Normal'],z.inputs[0])
    factor=n.new('ShaderNodeMapRange');factor.clamp=True;factor.interpolation_type='SMOOTHERSTEP'
    l.new(z.outputs['Z'],factor.inputs['Value'])
    factor.inputs['From Min'].default_value=.65;factor.inputs['From Max'].default_value=.972
    factor.inputs['To Min'].default_value=.83;factor.inputs['To Max'].default_value=.04
    split=n.new('ShaderNodeMixRGB');l.new(factor.outputs[0],split.inputs[0])
    l.new(cols[0],split.inputs[1]);l.new(cols[1],split.inputs[2])
    air=n.new('ShaderNodeMixRGB');air.inputs[0].default_value=spec['air_share']
    l.new(split.outputs[0],air.inputs[1]);air.inputs[2].default_value=(*spec['air'],1)
    l.new(air.outputs[0],p.inputs['Base Color'])
    # Subtle air-light floor on distant shaded faces. It compensates for
    # missing kilometre-scale participating media without affecting estate light transport.
    p.inputs['Emission Color'].default_value=(*spec['air'],1)
    p.inputs['Emission Strength'].default_value=spec['air_share']*.78
    m.diffuse_color=(*spec['air'],1)
    return m


def _make_ridge(spec,collection):
    xa,xb=spec['xspan'];ya,yb=spec['yspan']
    nx=math.ceil((xb-xa)/spec['step'])+1;ny=math.ceil((ya-yb)/spec['step'])+1
    xs=[xa+(xb-xa)*i/(nx-1) for i in range(nx)]
    ys=[ya+(yb-ya)*i/(ny-1) for i in range(ny)]
    profile=[_interp(spec['crest'],x) for x in xs]
    verts=[(x,y,_height(x,y,c,z,spec)) for y in ys for x,(c,z) in zip(xs,profile)]
    faces=[]
    for iy in range(ny-1):
        for ix in range(nx-1):
            a=iy*nx+ix
            faces.append((a,a+nx,a+nx+1,a+1))
    m=bpy.data.meshes.new(spec['label']);m.from_pydata(verts,[],faces);m.update()
    for p in m.polygons:p.use_smooth=True
    m.materials.append(_ridge_material(spec))
    o=bpy.data.objects.new('V6 Southern horizon | '+spec['label'],m);collection.objects.link(o)
    # Keep the approved environment's lighting and shadows intact; retain both
    # direct and through-glass camera visibility (and distant reflected context).
    o.visible_diffuse=False;o.visible_shadow=False
    o.visible_camera=True;o.visible_transmission=True;o.visible_glossy=True
    return o


def apply_horizon(scene=None):
    """Add south-only horizon context; return report with bounds/mesh counts."""
    scene=scene or bpy.context.scene
    if bpy.data.collections.get(GROUP) is not None:
        raise RuntimeError('Southern horizon already present; start from derived V6 without horizon.')
    group=bpy.data.collections.new(GROUP);scene.collection.children.link(group)
    objects=[_make_ridge(spec,group) for spec in RIDGES]
    records=[]
    for o in objects:
        zs=[q.co.z for q in o.data.vertices]
        xs=[q.co.x for q in o.data.vertices]
        ys=[q.co.y for q in o.data.vertices]
        records.append(dict(name=o.name,vertices=len(o.data.vertices),faces=len(o.data.polygons),
                            bounds_blender_m=[[min(a),max(a)] for a in (xs,ys,zs)]))
    assert all(row['bounds_blender_m'][1][1] < -170 for row in records)
    return {'southern_ridges':records,'exterior_hero_looks_away':True,
            'authored_north_mountains_preserved':True,'light_transport':'camera/transmission/glossy only; no world edits'}

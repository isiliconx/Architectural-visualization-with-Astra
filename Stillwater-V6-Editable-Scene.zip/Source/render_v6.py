"""Produce a verified Blender Cycles frame from one saved V6 camera."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import bpy

p=argparse.ArgumentParser(description=__doc__)
p.add_argument("--shot",choices=("01","02","03","04","05"),required=True)
p.add_argument("--out",type=Path,required=True)
p.add_argument("--width",type=int,default=960)
p.add_argument("--samples",type=int,default=32)
p.add_argument("--backend",choices=("OPTIX","CUDA"),default="OPTIX")
p.add_argument("--exposure-offset",type=float,default=0.)
a=p.parse_args(sys.argv[sys.argv.index("--")+1:])
assert 320<=a.width<=3500 and 8<=a.samples<=192 and abs(a.exposure_offset)<=.65
s=bpy.context.scene
assert s["revision"]=="V6" and bpy.app.version_string.startswith("4.5.3")
cam=next(o for o in s.objects if o.type=="CAMERA" and o.name.startswith(f"V6 | {a.shot} |"))
pref=bpy.context.preferences.addons["cycles"].preferences
pref.compute_device_type=a.backend
pref.get_devices()
devices=[]
for d in pref.devices:
    d.use=d.type==a.backend
    if d.use:devices.append(d.name)
assert devices,"NVIDIA renderer not available; CPU fallback is not allowed"
s.camera=cam
s.view_settings.exposure=float(cam.get("v6_exposure",-.10))+a.exposure_offset
s.cycles.device="GPU"
s.cycles.samples=a.samples
s.cycles.use_adaptive_sampling=True
s.cycles.adaptive_threshold=.030 if a.samples<=36 else .018
s.cycles.adaptive_min_samples=min(12,a.samples)
s.cycles.use_denoising=True
s.cycles.denoiser="OPENIMAGEDENOISE"
s.cycles.denoising_use_gpu=True
s.render.resolution_x=a.width;s.render.resolution_y=round(a.width*2/3)
s.render.resolution_percentage=100
s.render.image_settings.file_format="PNG"
s.render.image_settings.color_mode="RGB"
s.render.image_settings.color_depth="8"
s.render.image_settings.compression=34
s.render.use_file_extension=False
assert not a.out.exists() and a.out.suffix==".png"
a.out.parent.mkdir(exist_ok=True,parents=True)
tmp=a.out.with_suffix(".staging.png")
assert not tmp.exists()
s.render.filepath=str(tmp)
t=time.monotonic()
print("V6_RENDERING",json.dumps({"camera":cam.name,"backend":a.backend,"device":devices,
"width":a.width,"samples":a.samples,"exposure":s.view_settings.exposure}),flush=True)
bpy.ops.render.render(write_still=True)
assert tmp.stat().st_size>500 and tmp.read_bytes()[:8]==b"\x89PNG\r\n\x1a\n"
tmp.rename(a.out)
receipt={"name":a.out.name,"camera":cam.name,"backend":a.backend,"devices":devices,"samples":a.samples,
         "resolution":[s.render.resolution_x,s.render.resolution_y],"elapsed":time.monotonic()-t,
         "exposure":s.view_settings.exposure,"bytes":a.out.stat().st_size,
         "sha256":hashlib.sha256(a.out.read_bytes()).hexdigest()}
a.out.with_suffix(".receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print("V6_RENDERED",json.dumps(receipt),flush=True)

"""Stillwater V6 lived-in objects. Execute after opening V5 and loading build helpers."""
import math
import random
from mathutils import Vector
from math import tau, sin, cos, pi
_SW_LIVED_RNG=random.Random(41997)
active=collection('V6 | Lived-in objects and settings')
_SW_LIVED_COLLECTION=active
_SW_LIVED_CHECKS=[]
def _lo_xyz(x,y,z): return (x-16.5,y-.7,z)
def _lo_matte(name,color,rough=.72,metal=0):
    m=material('V6 lived-in | '+name,color,rough)
    bs=m.node_tree.nodes.get('Principled BSDF')
    if bs and 'Metallic' in bs.inputs:bs.inputs['Metallic'].default_value=metal
    return m
def _lo_glaze(name,a,b):
    return textured('V6 lived-in | '+name,a,b,18,.33,.12,.011)
_lo_porcelain=_lo_glaze('Ivory iron-speckled ceramic',(.60,.53,.41),(.85,.79,.69))
_lo_sand=_lo_glaze('Sandy oatmeal hand glaze',(.27,.16,.095),(.46,.34,.24))
_lo_olive=_lo_glaze('Deep muted sage hand glaze',(.073,.113,.071),(.167,.215,.125))
_lo_sienna=_lo_glaze('Rust red clay hand glaze',(.215,.064,.036),(.43,.185,.116))
_lo_brass=_lo_matte('Forged oxidized spoon',(.32,.24,.118),.28,.82)
_lo_pages=_lo_matte('Unbleached paper book block',(.76,.65,.49))
_lo_leafpage=_lo_matte('Ivory ruled journal paper',(.81,.75,.61),.7)
_lo_linework=_lo_matte('Printed graphite toned strokes',(.076,.064,.042))
_lo_espresso=_lo_matte('Espresso in deep black',(.026,.010,.005),.36)
_lo_stripe=_lo_matte('Soft espresso crema',(.371,.187,.077),.48)
_lo_dry=_lo_matte('Dried eucalyptus stem',(.127,.081,.043))
_lo_leaf=_lo_matte('Soft eucalyptus leaf',(.164,.205,.124))
_lo_cover=[_lo_matte(n,c) for n,c in [
    ('Moss linen clothbound',(.140,.169,.101)),('Brick linen clothbound',(.291,.096,.045)),('Oat clothbound',(.44,.325,.224)),('Charcoal binder',(.076,.080,.073))]]
_lo_peel=[_lo_glaze(n,a,b) for n,a,b in [('Pear skin',(.32,.31,.08),(.56,.53,.24)),('Fig skin',(.10,.04,.075),(.22,.085,.13)),('Tangerine peel',(.58,.165,.014),(.8,.32,.055))]]
_lo_flesh=_lo_matte('Freshly exposed citrus flesh',(.82,.34,.070),.49)
_lo_pith=_lo_matte('Orange pith',(.90,.67,.36),.68)
_lo_board=woodlight

def _lo_block(name,x,y,z,w,d,h,m,b=.004,a=0):
    return cube('V6 | '+name,_lo_xyz(x,y,z),(w,d,h),m,b,(0,0,a) if a else None)

def _lo_sphere(name,x,y,z,s,m):
    return sphere('V6 | '+name,_lo_xyz(x,y,z),s,m,20,12)

def _lo_curve(name, pts, width, m, closed=False):
    cu=bpy.data.curves.new('V6 | '+name,'CURVE');cu.dimensions='3D';cu.resolution_u=4
    cu.bevel_depth=width;cu.bevel_resolution=2
    sp=cu.splines.new('POLY');sp.points.add(len(pts)-1)
    for p,co in zip(sp.points,pts):p.co=(*_lo_xyz(*co),1)
    sp.use_cyclic_u=closed
    ob=bpy.data.objects.new(cu.name,cu);cu.materials.append(m);_SW_LIVED_COLLECTION.objects.link(ob)
    return ob

def _lo_thrown(name,x,y,z,profile,m,seed,irregular=.023):
    """Wall-and-rim shape, with a continuous inner surface when the profile returns."""
    r=random.Random(seed)
    j0,j1,j2=[r.uniform(0,tau) for _ in range(3)]
    rings=42
    xs=[];faces=[]
    for rr,zz in profile:
        for i in range(rings):
            a=tau*i/rings
            ra=rr*(1+irregular*(.52*sin(2*a+j0)+.35*cos(3*a+j1)+.40*sin(5*a+j2)))
            zs=zz+min(.0018,rr*.045)*sin(3*a+j0)*min(1,zz/.014)
            xs.append(_lo_xyz(x+ra*cos(a),y+ra*sin(a),z+zs))
    for n in range(len(profile)-1):
        for j in range(rings):
            a=n*rings+j;b=n*rings+(j+1)%rings
            faces.append((a,b,b+rings,a+rings))
    faces.extend([tuple(range(rings-1,-1,-1)),tuple(range((len(profile)-1)*rings,len(profile)*rings))])
    ob=mesh_obj('V6 | '+name,xs,faces,[m])
    for p in ob.data.polygons:p.use_smooth=p.loop_total==4
    return ob

def _lo_support(tag,x,y,z,surface):
    _SW_LIVED_CHECKS.append({'group':tag,'base_blender_m':list(_lo_xyz(x,y,z)),'support_match':surface})

def _lo_plate(name,x,y,z,m,seed,r=.13):
    return _lo_thrown(name,x,y,z,[(r*.51,0),(r*.63,.003),(r*.82,.009),(r*.96,.021),(r,.032),(r*.98,.036),(r*.94,.032),(r*.80,.021),(r*.63,.016),(r*.02,.015)],m,seed)

def _lo_cup(name,x,y,z,m,seed,angle=.1,coffee=False,s=.042):
    h=s*1.8
    _lo_thrown(name+' | wheel-thrown body',x,y,z,[(s*.65,0),(s*.74,.007),(s*.87,.024),(s,h-.004),(s*.974,h),(s*.875,h+.001),(s*.84,h-.018),(s*.69,.019),(s*.61,.014),(s*.02,.014)],m,seed)
    pts=[]
    for j in range(37):
        a=tau*j/36;d=s*.98+s*.435*(1+cos(a))
        pts.append((x+d*cos(angle),y+d*sin(angle),z+h*.58+h*.29*sin(a)))
    _lo_curve(name+' | pull-formed handle',pts,.0065,m,True)
    if coffee:
        _lo_thrown(name+' | espresso surface',x,y,z,[(s*.77,h-.017),(s*.77,h-.016),(s*.02,h-.016)],_lo_espresso,seed,0.)
        _lo_curve(name+' | slight crema ring',[(x+s*.68*cos(a*tau/42),y+s*.68*sin(a*tau/42),z+h-.015) for a in range(38)],.0012,_lo_stripe)

def _lo_napkin(name,x,y,z,a,m):
    vs=[];faces=[]
    m0=7; n=8
    for i in range(m0+1):
        u=.087*(i/m0-.5)
        for j in range(n+1):
            v=.17*(j/n-.5)
            zz=.001+.003*(1+sin(j*.38+i*.89))+.008*max(0,i/m0-.65)
            xx=x+u*cos(a)-v*sin(a);yy=y+u*sin(a)+v*cos(a);vs.append(_lo_xyz(xx,yy,z+zz))
    for i in range(m0):
        for j in range(n):
            u=i*(n+1)+j;faces.append((u,u+1,u+n+2,u+n+1))
    ob=mesh_obj('V6 | '+name,vs,faces,[m])
    for poly in ob.data.polygons:poly.use_smooth=True
    so=ob.modifiers.new('Editable thin cloth edge','SOLIDIFY');so.thickness=.0016
    return ob

def _lo_spoon(name,x,y,z,a,m,fork=False):
    def xy(u,v):return (x+u*cos(a)-v*sin(a),y+u*sin(a)+v*cos(a))
    xx,yy=xy(0,-.030)
    _lo_block(name+' | brushed handle',xx,yy,z+.006,.010,.109,.004,m,.002,a)
    xx,yy=xy(0,.045)
    if not fork:
        ob=_lo_sphere(name+' | shallow bowl',xx,yy,z+.006,(.016,.023,.006),m);ob.rotation_euler.z=a
    else:
        _lo_block(name+' | fork shoulder',xx,yy,z+.007,.022,.021,.004,m,.002,a)
        for i in range(4):
            xx,yy=xy((i-1.5)*.0057,.066)
            _lo_block(name+' | tine',xx,yy,z+.008,.0038,.025,.003,m,.001,a)

def _lo_book(name,x,y,z,w,d,h,a,material_index):
    c=_lo_cover[material_index%len(_lo_cover)]
    def block(tag,u,v,zz,ww,dd,hh,m):
        xx=x+u*cos(a)-v*sin(a);yy=y+u*sin(a)+v*cos(a)
        return _lo_block(name+' | '+tag,xx,yy,zz,ww,dd,hh,m,.001,a)
    block('bottom linen cover',0,0,z+.0018,w,d,.0036,c)
    block('top linen cover',0,0,z+h-.0018,w,d,.0036,c)
    block('deckled paper block',0,.002,z+h*.50,w-.010,d-.016,h-.006,_lo_pages)
    block('cloth spine',-w*.50+.0036,0,z+h*.50,.008,d,h,c)
    for i in range(3):
        v=-d*.29+i*.008
        block('small spine label',-w*.505,v,z+h*.54,.0015,.005,.009,_lo_pages)
    for i in range(4):
        block('faint edge leaves',0,d*.484,z+.005+(h-.01)*(i+.5)/4,w-.014,.0007,.0006,_lo_stripe)
    return z+h

def _lo_notebook(name,x,y,z,a):
    def xy(u,v,zv):
        return (x+u*cos(a)-v*sin(a),y+u*sin(a)+v*cos(a),zv)
    _lo_block(name+' | cloth board',x,y,z+.0025,.386,.246,.005,_lo_cover[3],.002,a)
    for side in (-1,1):
        vs=[]
        for i in range(7):
            u=i*.187/6
            for v in (-.119,.119):
                co=xy(side*u,v,z+.006+.013*sin(math.pi*u/.187)**.9)
                vs.append(_lo_xyz(*co))
        ob=mesh_obj('V6 | '+name+' | opened curved paper',vs,[(2*j,2*j+1,2*j+3,2*j+2) for j in range(6)],[_lo_leafpage])
        ob.modifiers.new('Thin paper relief','SOLIDIFY').thickness=.0012
        for row in range(6):
            v=.082-row*.027
            pts=[]
            for i in range(5):
                u=.020+i*.032
                pts.append(xy(side*u,v,z+.0068+.013*sin(math.pi*u/.187)**.9))
            _lo_curve(name+' | muted journal ruling',pts,.00058,_lo_linework)
    _lo_curve(name+' | linen thread at gutter',[xy(0,-.12,z+.008),xy(0,.12,z+.008)],.00112,_lo_cover[3])
    _lo_curve(name+' | diagonally laid graphite pencil',[xy(.015,.039,z+.021),xy(.126,-.055,z+.028)],.0035,_lo_cover[1])
    _lo_curve(name+' | graphite tip',[xy(.126,-.055,z+.028),xy(.136,-.063,z+.028)],.0022,_lo_linework)

# The design stays calm: four settings on a table for eight, no perfectly
# mirrored arrangements, and only a few objects per living/work surface.
for i,(x,y,a) in enumerate([(14.34,2.153,.10),(15.23,2.159,-.07),(16.13,2.776,3.04),(14.82,2.775,3.22)]):
    z=1.198
    tag=f'Dining table | used place setting {i+1}'
    _lo_support(tag,x,y,z,'Dining | oval-edged eight-seat table | shaped top')
    _lo_plate(tag+' | rolled ceramic rim',x,y,z,_lo_porcelain,101+i,.118 if i==2 else .125)
    side=1 if i<2 else -1
    _lo_napkin(tag+' | soft folded linen',x+.190*side,y-.012,z+.001,a+.12,sage if i==3 else linen)
    _lo_spoon(tag+' | small steel fork',x-.161*side,y+.004,z+.001,a,_lo_brass,True)
for x,y,i in [(14.76,2.28,0),(16.41,2.53,1)]:
    _lo_support('Dining | small tea cup',x,y,1.198,'Dining | oval-edged eight-seat table | shaped top')
    _lo_cup('Dining | imperfect tea cup',x,y,1.198,_lo_sand if i==0 else _lo_olive,93+i,2.04+i,coffee=i==0,s=.034)

# Dark counter: a working cutting board and a cloth slightly off square.
z=1.362
_lo_support('Island | cutting board and citrus',18.68,2.40,z,'Kitchen | walnut-front island | slab top')
_lo_block('Island | end-grain chopping board',18.68,2.40,z+.013,.49,.292,.026,_lo_board,.019,-.10)
_lo_thrown('Island | fresh cut orange rind',18.59,2.435,z+.027,[(.015,0),(.038,.016),(.045,.041),(.045,.044),(.034,.044),(.02,.042)],_lo_peel[2],429)
_lo_thrown('Island | exposed citrus segment face',18.59,2.435,z+.027,[(.043,.044),(.041,.046),(.003,.046)],_lo_flesh,429,.013)
for i in range(8):
    a=i*tau/8
    _lo_curve('Island | fine citrus segment pith',[(18.59,2.435,z+.074),(18.59+.041*cos(a),2.435+.041*sin(a),z+.074)],.00055,_lo_pith)
_lo_sphere('Island | still whole orange',18.76,2.428,z+.027+.038,(.043,.040,.040),_lo_peel[2])
_lo_sphere('Island | dimpled orange stem',18.763,2.428,z+.027+.079,(.005,.006,.0028),_lo_dry)
_lo_block('Island | short knife handle',18.79,2.305,z+.037,.103,.018,.018,_lo_cover[3],.006,-.10)
_lo_block('Island | brushed blade laid flat',18.681,2.319,z+.030,.111,.026,.003,_lo_brass,.002,-.10)
_lo_support('Island | lightly wrinkled hand cloth',19.53,2.72,z,'Kitchen | walnut-front island | slab top')
_lo_napkin('Island | loosely set hand cloth',19.53,2.72,z,-.41,linen)
_lo_support('Island | half-used coffee cup',19.04,2.63,z,'Kitchen | walnut-front island | slab top')
_lo_cup('Island | warm porcelain coffee cup',19.04,2.63,z,_lo_porcelain,37,1.02,True)

# Back countertop: useful utensils and a few irregular fruit shapes, offset
# from the dark induction hob and never occupying its cooking surface.
z=1.3525
_lo_support('Back kitchen | wheel thrown fruit bowl',20.49,5.75,z,'Kitchen | preparation counter | slab top')
_lo_thrown('Back kitchen | oval-lipped fruit bowl',20.49,5.75,z,[(.058,0),(.071,.005),(.099,.024),(.124,.063),(.121,.068),(.114,.065),(.093,.024),(.060,.013),(.007,.013)],_lo_sienna,119,.032)
for i,(dx,dy) in enumerate([(-.050,-.033),(.034,-.043),(.043,.036),(-.029,.044)]):
    xx=20.49+dx;yy=5.75+dy
    sc=[(.036,.035,.046),(.034,.041,.033),(.030,.032,.041),(.035,.037,.034)][i]
    _lo_sphere('Back kitchen | picked fruit',xx,yy,z+.027+sc[2],sc,_lo_peel[[0,1,0,2][i]])
    _lo_curve('Back kitchen | dried fruit stem',[(xx,yy,z+.027+2*sc[2]),(xx+.005,yy+.002,z+.036+2*sc[2])],.0015,_lo_dry)
_lo_support('Pantry | shelf jugs',18.84,9.53,2.156,'Pantry | open oak shelf')
for i,x in enumerate((18.68,18.85,19.05)):
    _lo_thrown('Pantry | shallow serving pitcher',x,9.54,2.156,[(.040,0),(.053,.018),(.049,.091),(.035,.107),(.041,.113),(.038,.117),(.031,.111),(.028,.092),(.031,.012),(.003,.012)],(_lo_porcelain,_lo_olive,_lo_sand)[i],311+i,.039)

# Reading traces: sewn covers on a selected book stack, open ruled journals
# in the study and atelier, and ceramics displaced from their symmetry axes.
z=.8405
_lo_support('Main living | reading cup',11.99,3.138,z,'Living | long travertine cocktail | round top')
_lo_plate('Main living | low-rise saucer',11.99,3.138,z,_lo_sand,97,.065)
_lo_cup('Main living | cooled coffee',11.99,3.138,z+.016,_lo_olive,86,.43,True,.032)
z=.8325
_lo_support('West salon | pile of collected books',5.56,3.12,z,'West salon | occasional stone table | round top')
z=_lo_book('West salon | gathered design monograph',5.56,3.12,z,.223,.180,.031,-.11,1)
_lo_book('West salon | slim olive spine paperback',5.55,3.14,z,.187,.145,.021,.17,0)
_lo_support('Study | open project notebook',1.94,9.065,1.1925,'Study | built-in worktop | shaped top')
_lo_notebook('Study | recently opened project notebook',1.94,9.065,1.1925,-.15)
_lo_support('Study | clay pencil cup',2.63,9.16,1.1925,'Study | built-in worktop | shaped top')
_lo_thrown('Study | uneven iron-oxide pen pot',2.63,9.16,1.1925,[(.036,0),(.043,.011),(.047,.095),(.045,.102),(.038,.101),(.037,.012),(.007,.012)],_lo_sienna,108)
for i,a in enumerate((.12,2.11,4.2)):
    _lo_curve('Study | sharpened colored pencil',[(2.63+.009*cos(a),9.16+.008*sin(a),1.203),(2.63+.047*cos(a),9.16+.047*sin(a),1.352+.016*i)],.0036,_lo_cover[i])
z=8.5875
_lo_support('Atelier | open measured sketchbook',12.40,7.555,z,'Atelier | long oak writers desk | shaped top')
_lo_notebook('Atelier | lay-open measured sketchbook',12.40,7.555,z,.17)
_lo_support('Atelier | vase and leaf stems',13.06,7.50,z,'Atelier | long oak writers desk | shaped top')
_lo_thrown('Atelier | asymmetric sage vase',13.06,7.50,z,[(.036,0),(.045,.009),(.062,.043),(.062,.086),(.047,.131),(.026,.158),(.026,.180),(.022,.181),(.020,.162),(.022,.151),(.045,.111),(.05,.025),(.004,.012)],_lo_olive,119,.041)
for i,a in enumerate((.34,2.21,4.83)):
    dx,dy=.084*cos(a),.084*sin(a)
    _lo_curve('Atelier | irregular twig',[(13.06,7.50,z+.143),(13.06+.35*dx,7.50+.35*dy,z+.230),(13.06+dx,7.50+dy,z+.334-.033*i)],.0017,_lo_dry)
    for j in range(2):
        s=.50+.33*j
        xx=13.06+dx*s;yy=7.50+dy*s;zz=z+.210+.045*j-.014*i
        leaf=_lo_sphere('Atelier | dried soft eucalypt leaf',xx,yy,zz,(.022,.009,.0029),_lo_leaf)
        leaf.rotation_euler=(.23*j,.31,a+.6-j*.9)

print('V6_LIVED_IN_OBJECTS_READY',len(_SW_LIVED_COLLECTION.objects),len(_SW_LIVED_CHECKS),flush=True)

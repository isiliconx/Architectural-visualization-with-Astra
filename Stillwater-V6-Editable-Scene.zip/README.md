# Stillwater House VI · Quiet Evening

This is a separate Blender appearance revision of the approved Stillwater V5.
The floor plan, house levels and circulation remain in place. V6 is not a
browser or Unreal update.

**Open** `Stillwater-House-V6.blend` in Blender 4.5.3 LTS. The scene opens on
the exterior camera. The **V6 | editorial cameras** collection has the five
review cameras. Extra geometry is organized in V6 landscape, architecture,
upholstery and lived-in collections. All render materials are contained in the
file; no external texture downloads are required.

The original V5 file remains unchanged. V6 adds 280 physically jointed stone
slabs, a recessed stainless sink, bent timber frames on 15 chairs, tailored
cushions and piping, ceramic tableware, books/journals and kitchen details.
Landscape revisions keep the near terrain and pathways, with refined conifers,
lawn detail, fractured mountain surfaces, and layered ridges behind the main
glazing. The existing golden-hour atmosphere is retained with more restrained
window fill and warm practical lighting.

The five PNGs were rendered from the saved V6 in Blender Cycles on MoLab's
NVIDIA RTX PRO 6000 Blackwell GPU (OptiX). The per-camera exposure starting
points are stored as `v6_exposure` custom properties. The scene itself opens
with portable CPU render defaults; the included script explicitly selects the
available OptiX or CUDA GPU for these rendered comparisons.

## Reproduce the model and render

From the bundled Source folder:

```sh
blender -b /your/approved/Stillwater-House-V5.blend --python-exit-code 3 \
  --python build_v6.py -- --out /your/new/Stillwater-House-V6.blend

blender -b /your/new/Stillwater-House-V6.blend --python-exit-code 4 \
  --python render_v6.py -- --shot 02 --out /your/new/Living.png \
  --width 1920 --samples 64 --backend OPTIX
```

All dimensions are scene design units for an architectural visualization,
not construction documents.

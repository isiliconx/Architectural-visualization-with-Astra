"""Small-scale V6 architecture detail and meter-scale material response."""
from math import sin,cos
import json, random
import bpy
from mathutils import Vector

def mat_for(prefix):
    return next(m for m in bpy.data.materials if m.name.startswith(prefix+" | "))

def bsdf(mat):
    return next(n for n in mat.node_tree.nodes if n.type=="BSDF_PRINCIPLED")

def proc(mat):
    return mat.node_tree.nodes,mat.node_tree.links,bsdf(mat)

def connect(links, src, dst):
    for l in tuple(dst.links): links.remove(l)
    links.new(src,dst)

def ramp(nodes, links, tex, keys, label):
    n=nodes.new("ShaderNodeValToRGB")
    n.label=label
    cols=n.color_ramp.elements
    while len(cols)>2: cols.remove(cols[-1])
    cols[0].position,cols[0].color=keys[0]
    cols[1].position,cols[1].color=keys[-1]
    for k,v in keys[1:-1]: cols.new(k).color=v
    links.new(tex,n.inputs[0])
    return n.outputs["Color"]

def noise(n,l,coordinate,scale,detail,rough,label):
    tex=n.new("ShaderNodeTexNoise");tex.label=label
    tex.inputs["Scale"].default_value=scale
    tex.inputs["Detail"].default_value=detail
    tex.inputs["Roughness"].default_value=rough
    l.new(coordinate,tex.inputs["Vector"])
    return tex.outputs["Fac"]

def scale_axis(n,l,coordinate,xyz,label):
    s=n.new("ShaderNodeVectorMath");s.operation="MULTIPLY";s.label=label
    l.new(coordinate,s.inputs[0]);s.inputs[1].default_value=xyz
    return s.outputs["Vector"]

def mapped(n,l,t,low,high):
    m=n.new("ShaderNodeMapRange"); m.clamp=True
    m.inputs["From Min"].default_value=.21;m.inputs["From Max"].default_value=.79
    m.inputs["To Min"].default_value=low;m.inputs["To Max"].default_value=high
    l.new(t,m.inputs["Value"])
    return m.outputs[0]

def bump(n,l,bs,tex,strength,distance, label):
    b=n.new("ShaderNodeBump")
    b.inputs["Strength"].default_value=strength
    b.inputs["Distance"].default_value=distance
    b.label=label
    l.new(tex,b.inputs["Height"])
    connect(l,b.outputs["Normal"],bs.inputs["Normal"])

def c(rgb):
    return (*rgb,1)

def tint(rgb,factor):
    return tuple(max(0.,min(1.,x*factor)) for x in rgb)

def stone_response(mat,is_travertine,fade=1.,rough=None):
    n,l,bs=proc(mat)
    p=n.new("ShaderNodeNewGeometry").outputs["Position"]
    f=(.54,3.0,.91) if is_travertine else (1.,1.4,2.2)
    g=scale_axis(n,l,p,f,"Long-cut veining in world meters")
    bands=noise(n,l,g,5.8 if is_travertine else 3.8,4.1,.61,"Subtle veins and bedding")
    pores=noise(n,l,p,138 if is_travertine else 166,2.0,.72,"Microscopic mineral grain")
    pair=([(.299,.263,.219),(.351,.313,.262),(.392,.353,.299),(.44,.400,.348)]
          if is_travertine else
          [(.369,.321,.243),(.448,.390,.300),(.487,.432,.338),(.566,.505,.411)])
    base=ramp(n,l,bands,list(zip((.17,.41,.635,.83),map(lambda rgb:c(tint(rgb,fade)),pair))),"Minerals, not high-contrast marbling")
    mix=n.new("ShaderNodeMixRGB");mix.blend_type="MULTIPLY";mix.inputs[0].default_value=.21
    l.new(base,mix.inputs[1]);l.new(ramp(n,l,pores,[(.29,(.54,.52,.49,1)),(.63,(1,1,1,1))],"Tiny mineral pits"),mix.inputs[2])
    connect(l,mix.outputs["Color"],bs.inputs["Base Color"])
    lo,hi=rough or ((.48,.66) if is_travertine else (.52,.71))
    connect(l,mapped(n,l,pores,lo,hi),bs.inputs["Roughness"])
    bump(n,l,bs,pores,.20 if is_travertine else .23,.0018 if is_travertine else .0023,"Fine honed relief")
    bs.inputs["IOR"].default_value=1.48

def wood_response(mat,smoked):
    n,l,bs=proc(mat)
    p=n.new("ShaderNodeTexCoord").outputs["Object"]
    g=scale_axis(n,l,p,(.36,19.,2.65),"Sliced in length, not mapped by object size")
    grain=noise(n,l,g,7.6,3.5,.64,"Oiled longitudinal wood grain")
    fine=noise(n,l,g,23,1.6,.66,"Vessel pores")
    tonal=([(.076,.042,.023),(.100,.059,.033),(.126,.077,.045),(.155,.100,.060)]
           if smoked else [(.205,.125,.058),(.269,.173,.089),(.321,.215,.120),(.380,.263,.152)])
    mix=ramp(n,l,grain,list(zip((.19,.38,.64,.86),map(c,tonal))),"Natural wood-tones, close in value")
    connect(l,mix,bs.inputs["Base Color"])
    connect(l,mapped(n,l,fine,.34 if smoked else .36,.52 if smoked else .48),bs.inputs["Roughness"])
    bump(n,l,bs,fine,.22,.0017,"Open pores catch reflected light")
    bs.inputs["Coat Weight"].default_value=.055
    bs.inputs["Coat Roughness"].default_value=.38

def other_response():
    plaster=mat_for("03"); n,l,b=proc(plaster)
    p=n.new("ShaderNodeNewGeometry").outputs["Position"]
    tex=noise(n,l,p,104,2.7,.66,"Fine hand-floated plaster")
    connect(l,mapped(n,l,tex,.76,.88),b.inputs["Roughness"])
    bump(n,l,b,tex,.13,.0018,"A whisper of plaster tooth")
    basalt=mat_for("11");n,l,b=proc(basalt)
    p=n.new("ShaderNodeNewGeometry").outputs["Position"]
    spots=noise(n,l,p,91,2.7,.67,"Dense dark stone mineral flecks")
    tones=ramp(n,l,spots,[(.23,(.018,.021,.019,1)),(.49,(.030,.032,.027,1)),(.74,(.041,.042,.036,1))],"Avoid a perfectly black counter")
    connect(l,tones,b.inputs["Base Color"]);connect(l,mapped(n,l,spots,.32,.49),b.inputs["Roughness"])
    bump(n,l,b,spots,.16,.0011,"Basalt microrelief")
    for key,lo,hi,axes,amp in [("09",.26,.38,(.6,8.,5.),.07),("10",.24,.36,(.3,13.,6.),.09)]:
        m=mat_for(key);n,l,b=proc(m)
        p=n.new("ShaderNodeTexCoord").outputs["Object"]
        q=scale_axis(n,l,p,axes,"Extruded longitudinal brushed finish")
        s=noise(n,l,q,119.,1.6,.69,"Anodized or burnished machining grain")
        connect(l,mapped(n,l,s,lo,hi),b.inputs["Roughness"])
        bump(n,l,b,s,amp,.0009,"Brushing in reflected highlights")
        k=b.inputs.get("Anisotropic") or b.inputs.get("Anisotropic IOR Level")
        if k: k.default_value=.31
    glass=bsdf(mat_for("18"))
    glass.inputs["Base Color"].default_value=(.945,.974,.963,1)
    glass.inputs["Roughness"].default_value=.025
    glass.inputs["IOR"].default_value=1.457

def polys_box(geometry,x0,x1,y0,y1,z0,z1,mat):
    v,f,slot=geometry
    b=len(v)
    v.extend([(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),
              (x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)])
    f.extend(tuple(b+t for t in a) for a in ((0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)))
    slot.extend([mat]*6)

def stone_floor(group):
    base=bpy.data.objects["L1 | honed continuous interior floor"]
    dims=base.dimensions
    assert all(abs(a-b)<.001 for a,b in zip(dims,(32,10,.11)))
    before=base.matrix_world.copy()
    parent=mat_for("02")
    base.data=base.data.copy()
    for v in base.data.vertices:
        if v.co.z>0: v.co.z-=.0035
    grout=bpy.data.materials.new("V6 architecture | Mineral grout, 2.4 mm joints")
    grout.diffuse_color=(.267,.218,.154,1);grout.use_nodes=True
    b=bsdf(grout);b.inputs["Base Color"].default_value=grout.diffuse_color;b.inputs["Roughness"].default_value=.83
    base.data.materials[0]=grout
    cases=[]
    for i,f in enumerate((.955,.981,1.0,1.022,1.046)):
        m=parent.copy();m.name=f"V6 architecture | Interior honed travertine lot {i+1}"
        stone_response(m,True,f,(.38,.55))
        cases.append(m)
    geo=([],[],[])
    randomize=random.Random(1446)
    xmin,xmax,ymin,ymax=-16.50,15.50,-.70,9.30
    course=.735;length=1.665;gap=.0024
    y=ymin;row=0
    while y<ymax-.001:
        y1=min(y+course,ymax)
        x=xmin-(row%3)*length/3
        while x<xmax:
            lo=max(x,xmin);hi=min(x+length,xmax)
            if hi-lo>.015:
                polys_box(geo,lo+(gap/2 if lo>xmin else 0),hi-(gap/2 if hi<xmax else 0),y+(gap/2 if y>ymin else 0),y1-(gap/2 if y1<ymax else 0),.4154,.42015,randomize.choices(range(5),[3,5,10,5,3])[0])
            x+=length
        row+=1;y=y1
    v,f,slot=geo
    m=bpy.data.meshes.new("Editable stone courses")
    m.from_pydata(v,[],f);m.update()
    ob=bpy.data.objects.new("V6 | Sequential-cut travertine floor and physical joints",m);group.objects.link(ob)
    for material in cases:m.materials.append(material)
    m.polygons.foreach_set("material_index",slot)
    bevel=ob.modifiers.new("Millimeter arris on each stone course","BEVEL");bevel.width=.00085;bevel.segments=2
    ob.modifiers.new("Weighted honed faces","WEIGHTED_NORMAL")
    assert base.matrix_world==before
    ob["story"]="Vein-cut honed floor. Approximate 2.4mm open mineral joints and five quarry-lot variations."
    return {"floorSlabs":len(v)//8,"heightAtUpperSurfaceM":.42015,"jointWidthMM":2.4}
def rounded_ring(w,d,r,z,points=9):
    from math import pi
    out=[]
    for i,(x,y) in enumerate(((w/2-r,d/2-r),(-w/2+r,d/2-r),(-w/2+r,-d/2+r),(w/2-r,-d/2+r))):
        for j in range(points):
            a=(i+j/(points-1))*pi/2
            out.append((3.92+x+r*cos(a),1.67+y+r*sin(a),z))
    return out

def sink_detail(group):
    def from_data(name,vs,fs):
        me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update()
        ob=bpy.data.objects.new(name,me);group.objects.link(ob)
        return ob
    n=36
    profile=[(.485,.327,.042,1.398),(.485,.327,.042,1.115)]
    verts=sum([rounded_ring(*r) for r in profile],[])
    face=[tuple(range(n)),tuple(range(2*n-1,n-1,-1))]
    face.extend((i,i+n,(i+1)%n+n,(i+1)%n) for i in range(n))
    cutter=from_data("V6 | Temporary countertop sink pocket cutter",verts,face)
    bpy.context.view_layer.update()
    assembly=[]
    for name in ("Kitchen | walnut-front island | slab top","Kitchen | walnut-front island | box"):
        ob=bpy.data.objects[name]
        original=max(ob.dimensions)
        b=ob.modifiers.new("Recess for actual sink bowl","BOOLEAN")
        b.operation="DIFFERENCE";b.solver="EXACT";b.object=cutter
        ob.modifiers.move(len(ob.modifiers)-1,0)
        with bpy.context.temp_override(object=ob,active_object=ob,selected_objects=[ob],selected_editable_objects=[ob]):
            assert bpy.ops.object.modifier_apply(modifier=b.name)=={"FINISHED"}
        assert abs(max(ob.dimensions)-original)<.002
        assembly.append(len(ob.data.polygons))
    bpy.data.objects.remove(cutter,do_unlink=True)
    old=bpy.data.objects["Kitchen | deep undermount well"]
    old.hide_render=True;old.hide_viewport=True
    material=bpy.data.materials.new("V6 architecture | Satin graphite stainless")
    material.use_nodes=True;material.diffuse_color=(.052,.062,.064,1)
    br=bsdf(material)
    br.inputs["Base Color"].default_value=material.diffuse_color
    br.inputs["Metallic"].default_value=.79;br.inputs["Roughness"].default_value=.39
    rings=[(.482,.324,.040,1.354),(.472,.315,.039,1.349),(.456,.297,.036,1.337),
           (.437,.277,.034,1.216),(.421,.261,.034,1.201),(.382,.231,.028,1.197)]
    verts=sum([rounded_ring(*r) for r in rings],[])
    faces=[]
    for j in range(len(rings)-1):
        for i in range(n):
            a=j*n+i;b=j*n+(i+1)%n
            faces.append((a,b,b+n,a+n))
    faces.append(tuple(range(len(verts)-n,len(verts))))
    bowl=from_data("V6 | Recessed satin-metal undermount sink bowl",verts,faces)
    bowl.data.materials.append(material)
    for p in bowl.data.polygons:p.use_smooth=p.loop_total==4
    thick=bowl.modifiers.new("Folded stainless wall thickness","SOLIDIFY");thick.thickness=.002
    for j,(radius,z) in enumerate(((.026,1.199),(.0224,1.200),(.019,1.201))):
        pos=[] 
        for k in range(40):
            from math import tau
            t=tau*k/40
            pos.append((3.927+radius*cos(t),1.675+radius*sin(t),z))
        curve=bpy.data.curves.new(f"V6 | machined drain ring {j+1}","CURVE");curve.dimensions="3D"
        curve.bevel_depth=.0012;curve.bevel_resolution=3
        spl=curve.splines.new("POLY");spl.points.add(len(pos)-1);spl.use_cyclic_u=True
        for v,point in zip(spl.points,pos):v.co=(*point,1)
        curve.materials.append(mat_for("10"))
        obj=bpy.data.objects.new(curve.name,curve);group.objects.link(obj)
    bpy.context.view_layer.update()
    from mathutils.bvhtree import BVHTree
    dep=bpy.context.evaluated_depsgraph_get()
    top=bpy.data.objects["Kitchen | walnut-front island | slab top"]
    inverse=top.matrix_world.inverted();down=Vector((0,0,-1))
    assert BVHTree.FromObject(top,dep).ray_cast(inverse@Vector((3.92,1.67,1.406)),down,.097)[0] is None
    assert BVHTree.FromObject(top,dep).ray_cast(inverse@Vector((2.78,1.67,1.406)),down,.097)[0] is not None
    return {"recessDepthM":.157,"carcassAndSlabPolygons":assembly,"centerOpeningVerified":True}

def apply_architecture(scene):
    group=bpy.data.collections.new("V6 | Architectural material and stonework")
    scene.collection.children.link(group)
    stone_response(mat_for("01"),False)
    stone_response(mat_for("02"),True)
    wood_response(mat_for("04"),True)
    wood_response(mat_for("05"),False)
    other_response()
    data=stone_floor(group)
    data["sink"]=sink_detail(group)
    print("V6_ARCHITECTURE",json.dumps(data),flush=True)
    return data

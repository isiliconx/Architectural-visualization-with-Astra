"""Compound-curved bent ash chair frames. Apply to a loaded V5/V6 Blender scene.

The original chair seats, backs, and member object identities stay in place.
Rails use closed editable swept meshes with lengthwise grain UVs, and meet
their existing cushions and the surveyed floor. No external assets.
"""
import bpy
import math
import re
import hashlib
from collections import Counter
from mathutils import Vector

_FAMILIES=('Living oak chair','Dining | ash chair','Dining | end chair',
          'Study | upholstered desk chair','Roof lounge | pool-facing oak seat',
          'Bedroom balcony | oak chair','Atelier | facing the mountain')
_EPS=1e-5

def _materials():
    grain=bpy.data.materials.get('V6 | Steam-bent oiled ash')
    if grain is None:
        grain=bpy.data.materials.new('V6 | Steam-bent oiled ash');grain.use_nodes=True
        grain.diffuse_color=(.36,.253,.147,1)
        n=grain.node_tree.nodes;l=grain.node_tree.links;bs=n.get('Principled BSDF')
        bs.inputs['Roughness'].default_value=.49
        bs.inputs['Coat Weight'].default_value=.10
        bs.inputs['Coat Roughness'].default_value=.54
        uv=n.new('ShaderNodeTexCoord')
        v=n.new('ShaderNodeVectorMath');v.operation='MULTIPLY'
        v.inputs[1].default_value=(120.,3.4,1.);l.new(uv.outputs['UV'],v.inputs[0])
        no=n.new('ShaderNodeTexNoise');no.inputs['Scale'].default_value=10.5
        no.inputs['Detail'].default_value=2.2;no.inputs['Roughness'].default_value=.63
        no.inputs['Distortion'].default_value=.31;l.new(v.outputs[0],no.inputs['Vector'])
        c=n.new('ShaderNodeValToRGB')
        c.color_ramp.elements[0].position=.18;c.color_ramp.elements[0].color=(.228,.155,.085,1)
        c.color_ramp.elements[1].position=.86;c.color_ramp.elements[1].color=(.495,.362,.212,1)
        l.new(no.outputs['Fac'],c.inputs['Fac']);l.new(c.outputs[0],bs.inputs['Base Color'])
        b=n.new('ShaderNodeBump');b.inputs['Distance'].default_value=.00047;b.inputs['Strength'].default_value=.19
        l.new(no.outputs['Fac'],b.inputs['Height']);l.new(b.outputs['Normal'],bs.inputs['Normal'])
    peg=bpy.data.materials.get('V6 | End-grain ash dowel')
    if peg is None:
        peg=bpy.data.materials.new('V6 | End-grain ash dowel');peg.use_nodes=True
        peg.diffuse_color=(.207,.127,.067,1);bs=peg.node_tree.nodes.get('Principled BSDF')
        bs.inputs['Base Color'].default_value=peg.diffuse_color
        bs.inputs['Roughness'].default_value=.74
    return grain,peg

def _catmull(anchors,n=8):
    a=list(map(Vector,anchors));out=[]
    for i,(b,c) in enumerate(zip(a,a[1:])):
        a0=a[max(0,i-1)];d=a[min(i+2,len(a)-1)]
        for j in range(n):
            t=j/n
            out.append(.5*(2*b+(c-a0)*t+(2*a0-5*b+4*c-d)*t*t+(-a0+3*b-3*c+d)*t*t*t))
    return out+[a[-1]]

def _mix_seq(a,u):
    j=min(len(a)-2,int(u*(len(a)-1)));p=u*(len(a)-1)-j
    return a[j]*(1-p)+a[j+1]*p

def _sweep(pts,rr,ref=(1,0,0),closed=False,radial=16,exponent=1.):
    """Swept end-capped oval / softened-rectangle section, UV v along grain."""
    v=[];f=[];uv=[];N=len(pts);V=[0.]
    for i,p in enumerate(pts):
        prev=pts[(i-1)%N] if closed or i else p
        nxt=pts[(i+1)%N] if closed or i+1<N else p
        t=(nxt-prev).normalized()
        a=(Vector(ref)-t*t.dot(Vector(ref))).normalized();b=t.cross(a).normalized()
        assert a.length>.99 and b.length>.99
        A,B=rr(i/(N-1))
        for j in range(radial):
            z=j*math.tau/radial;co=math.cos(z);si=math.sin(z)
            v.append(p+a*A*math.copysign(abs(co)**exponent,co)+b*B*math.copysign(abs(si)**exponent,si))
        V.append(V[-1]+(pts[(i+1)%N]-p).length)
    for i in range(N if closed else N-1):
        k=(i+1)%N
        for j in range(radial):
            next=(j+1)%radial
            f.append((i*radial+j,i*radial+next,k*radial+next,k*radial+j))
            a,b=j/radial*.098,(j+1)/radial*.098
            uv.append(((a,V[i]),(b,V[i]),(b,V[i+1]),(a,V[i+1])))
    if not closed:
        f.extend((tuple(range(radial-1,-1,-1)),tuple(range((N-1)*radial,N*radial))))
        for _ in range(2):uv.append([(math.cos(j*math.tau/radial)*.012,math.sin(j*math.tau/radial)*.012) for j in range(radial)])
    return v,f,uv

def _install(source,seat,basis,coords,mat,feature):
    vertices,faces,chart=coords
    name='V6 | '+feature+' | '+seat.name
    name=name[:55]+' '+hashlib.sha1(name.encode()).hexdigest()[:7]
    data=bpy.data.meshes.new(name)
    if source is None:
        data.from_pydata(vertices,[],faces)
        o=bpy.data.objects.new(name,data);seat.users_collection[0].objects.link(o);o.matrix_world=basis
    else:
        inverse=source.matrix_world.inverted()@basis
        data.from_pydata([inverse@v for v in vertices],[],faces)
        o=source;old=o.data;o.data=data
        if old.users==0:bpy.data.meshes.remove(old)
    data.update();data.materials.append(mat)
    for p in data.polygons:p.use_smooth=True
    lay=data.uv_layers.new(name='Continuous swept grain / meters')
    lay.data.foreach_set('uv',[a for f in chart for pair in f for a in pair])
    o['chair_frame_v6']=feature;o['chair_seat']=seat.name
    return o

def _support(scene,dep,basis,x,y):
    p=basis@Vector((x,y,.104));down=Vector((0,0,-1))
    for _ in range(9):
        hit,co,n,idx,o,ma=scene.ray_cast(dep,p,down,distance=.22)
        if not hit:break
        if n.z>.85 and all(t not in o.name for t in ('tapered oak leg','low back upright')):
            return co.z-basis.translation.z,o.name
        p=co+down*.001
    raise ValueError(f'No chair-foot support at {tuple(p)}')

def _hull(points):
    a=sorted(set(points));r=[]
    def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    for ordered in (a,a[::-1]):
        v=[]
        for p in ordered:
            while len(v)>1 and cross(v[-2],v[-1],p)<=1e-10:v.pop()
            v.append(p)
        r.extend(v[:-1])
    return r

def _leg(sx,sy,base):
    # Two bends in plan plus a restrained reverse sweep in side elevation.
    ztop=.447
    if sy<0:
        anchors=[(sx*.180,-.165,base),(sx*.177,-.158,base+.035),
                 (sx*.146,-.128,.157),(sx*.137,-.124,.261),
                 (sx*.149,-.143,.360),(sx*.161,-.154,ztop)]
    else:
        anchors=[(sx*.180,.165,base),(sx*.177,.158,base+.035),
                 (sx*.148,.131,.153),(sx*.144,.137,.270),
                 (sx*.160,.154,.387),(sx*.166,.163,ztop+.023)]
    pts=_catmull(anchors)
    def r(u):
        a=_mix_seq([.0114,.0126,.0147,.0132,.0114,.0125],u)
        b=_mix_seq([.0147,.015,.0175,.0153,.0147,.015],u)
        return a,b
    return _sweep(pts,r,exponent=.78)

def _upright(sx):
    p=_catmull([(sx*.161,.158,.402),(sx*.166,.166,.469),(sx*.171,.172,.530),
                (sx*.184,.193,.599),(sx*.188,.215,.675),(sx*.182,.220,.777),(sx*.179,.213,.849)])
    def rr(u):return _mix_seq([.012,.014,.015,.014,.012],u),_mix_seq([.014,.016,.018,.017,.012],u)
    return _sweep(p,rr,exponent=.76)

def _rim():
    pts=[]
    for i in range(112):
        t=math.tau*i/112;c,s=math.cos(t),math.sin(t)
        pts.append(Vector((.181*math.copysign(abs(c)**.54,c),.177*math.copysign(abs(s)**.54,s),
                           .431+.0028*math.cos(2*t))))
    return _sweep(pts,lambda u:(.0145,.0115),ref=(0,0,1),closed=True,exponent=.53)

def _back_rail():
    pts=_catmull([(-.184,.215,.686),(-.102,.229,.684),(0,.235,.677),
                  (.102,.229,.684),(.184,.215,.686)])
    return _sweep(pts,lambda u:(.011,.009),ref=(0,0,1),exponent=.64)
 
def _pin(x,y,z,sx):
    # End-grain dowel through the angled seat-frame mortise; visible on the inward face.
    path=[Vector((x-sx*.008,y,z)),Vector((x+sx*.010,y+.001,z+.0006))]
    return _sweep(path,lambda u:(.0032,.0032),ref=(0,0,1),radial=10)

def apply_chair_frames():
    scene=bpy.context.scene
    if scene.get('V6 chair frames verified'):raise RuntimeError('Chair frames already applied')
    bpy.context.view_layer.update()
    dep=bpy.context.evaluated_depsgraph_get()
    grain,peg=_materials();chairs={k:[] for k in _FAMILIES}
    for o in list(scene.objects):
        if o.type!='MESH':continue
        prefix,_,tag=re.sub(r'\.\d{3}$','',o.name).rpartition(' | ')
        if prefix in chairs and (tag=='seat' or tag.startswith(('tapered oak leg','low back upright','curved upholstered bac'))):
            chairs[prefix].append((o,tag))
    report=[];total=Counter();setup=[]
    # First survey all chairs and contact points before modifying the scene.
    for family,objs in chairs.items():
        seats=[o for o,t in objs if t=='seat']
        if not seats:raise ValueError((family,'missing seats'))
        groups={o.name:[] for o in seats}
        for o,t in objs:
            if t=='seat':continue
            nearest=min(seats,key=lambda s:(s.location.xy-o.location.xy).length)
            groups[nearest.name].append((o,t))
        for seat in seats:
            items=groups[seat.name]
            legs=[o for o,t in items if t.startswith('tapered oak leg')]
            backs=[o for o,t in items if t.startswith('low back upright')]
            if len(legs)!=4 or len(backs)!=2:raise ValueError((seat.name,len(legs),len(backs)))
            basis=seat.matrix_world.copy();basis.translation.z-=.466
            inv=basis.inverted()
            soles=[(*[1 if q>0 else -1 for q in (inv@o.location)[:2]],o) for o in legs]
            feet={(sx,sy):_support(scene,dep,basis,sx*.180,sy*.165) for sx,sy,_ in soles}
            if any(h<-.085 or h>.073 for h,_ in feet.values()):raise ValueError((seat.name,'unexpected floor height',feet))
            # Original full chair footprint incl. upholstery. Even the small
            # joinery details must not grow past this hull in plan.
            hull_points=[]
            for o in [seat]+[o for o,_ in items]:
                eo=o.evaluated_get(dep);mesh=eo.to_mesh();local=inv@eo.matrix_world
                hull_points.extend(tuple((local@v.co)[:2]) for v in mesh.vertices)
                eo.to_mesh_clear()
            footprint=_hull(hull_points)
            setup.append((seat,basis,footprint,soles,feet,backs))
    if len(setup)!=15:raise ValueError(('Unexpected chair count',len(setup)))
    for seat,basis,footprint,soles,feet,backs in setup:
        meshes=[]
        for sx,sy,o in soles:
            base,_=feet[sx,sy]
            # Lower the short protective sole into its local floor plane; all
            # original footing X,Y centers remain exactly where authored.
            coords=_leg(sx,sy,base)
            coords[0][:16]=[Vector((q.x,q.y,base)) for q in coords[0][:16]]
            meshes.append((o,coords,grain,'bent front leg' if sy<0 else 'bent rear leg'))
        for o in backs:
            sx=1 if (basis.inverted()@o.location).x>0 else -1
            meshes.append((o,_upright(sx),grain,'compound bent back stanchion'))
        meshes.extend(((None,_rim(),grain,'steam-bent ash seat apron'),
                       (None,_back_rail(),grain,'curved back mortise rail')))
        for sx,sy in feet:
            meshes.append((None,_pin(sx*.166,sy*.153,.432,sx),peg,'visible ash through-dowel'))
        edge=[(Vector((*a,0)),Vector((*b,0))) for a,b in zip(footprint,footprint[1:]+footprint[:1])]
        over=max(max(-(b-a).cross(v-a).z/(b-a).length for a,b in edge) for _,(vv,_,_),_,_ in meshes for v in vv)
        if over>.0011:
            raise ValueError((seat.name,'curved frame extends beyond footprint',over))
        for source,mesh,mat,feature in meshes:
            _install(source,seat,basis,mesh,mat,feature);total[feature]+=1
        report.append({'seat':seat.name,'foot_surfaces':sorted({a for _,a in feet.values()}),
                       'floor_contact_offset_m':[round(min(a for a,_ in feet.values()),5),round(max(a for a,_ in feet.values()),5)],
                       'footprint_growth_m':round(max(0.,over),6)})
    scene['V6 chair frames verified']=True
    bpy.context.view_layer.update()
    return {'chairs':len(setup),'members':dict(total),'footnotes':report,
            'maximum_xy_footprint_growth_m':max(i['footprint_growth_m'] for i in report)}

if __name__=='__main__':
    import json
    print('V6_CHAIR_FRAMES',json.dumps(apply_chair_frames()),flush=True)
